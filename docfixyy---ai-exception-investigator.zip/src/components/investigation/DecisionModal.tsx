import React, { useState } from 'react';
import { CheckCircle2, PauseCircle, XCircle, AlertTriangle, ShieldAlert } from 'lucide-react';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { InvestigationException } from '../../types/exception';
import { useStore } from '../../hooks/useStore';

interface DecisionModalProps {
  isOpen: boolean;
  onClose: () => void;
  exception: InvestigationException;
  decisionType: 'APPROVED' | 'HELD' | 'REJECTED';
}

export const DecisionModal: React.FC<DecisionModalProps> = ({
  isOpen,
  onClose,
  exception,
  decisionType,
}) => {
  const [state, store] = useStore();
  const { currentUser } = state;
  const [reason, setReason] = useState(
    decisionType === 'HELD'
      ? 'Placed on HOLD for Procurement review. Requesting revised invoice for 95 units or proof of delivery.'
      : decisionType === 'APPROVED'
      ? 'Authorized under exception override. Vendor promised credit adjustment next billing cycle.'
      : 'Rejected due to irreconcilable discrepancy and recurring vendor shortage.'
  );
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const isOverride = decisionType === 'APPROVED' && exception.type === 'QUANTITY_MISMATCH';

  const handleConfirm = () => {
    if (!reason.trim()) {
      setError('Please provide a mandatory decision rationale for the audit trail.');
      return;
    }
    setIsSubmitting(true);
    setTimeout(() => {
      store.recordHumanDecision(exception.txnId, exception.id, decisionType, reason.trim());
      setIsSubmitting(false);
      onClose();
    }, 400);
  };

  const getHeaderIcon = () => {
    switch (decisionType) {
      case 'APPROVED':
        return <CheckCircle2 className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />;
      case 'HELD':
        return <PauseCircle className="w-6 h-6 text-amber-600 dark:text-amber-400" />;
      case 'REJECTED':
        return <XCircle className="w-6 h-6 text-rose-600 dark:text-rose-400" />;
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={
        <div className="flex items-center gap-2">
          {getHeaderIcon()}
          <span>Confirm Human Decision: {decisionType}</span>
        </div>
      }
      subtitle={`Authorizing user: ${currentUser.name} (${currentUser.role})`}
      maxWidth="lg"
      footer={
        <div className="flex items-center justify-end gap-2 w-full">
          <Button variant="outline" size="sm" onClick={onClose} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button
            variant={decisionType === 'APPROVED' ? 'primary' : decisionType === 'HELD' ? 'warning' : 'danger'}
            size="sm"
            onClick={handleConfirm}
            isLoading={isSubmitting}
          >
            Record Decision & Log Audit
          </Button>
        </div>
      }
    >
      <div className="space-y-4">
        {/* Risk Warning on Override */}
        {isOverride && (
          <div className="p-3.5 bg-rose-50 dark:bg-rose-950/40 rounded-lg border border-rose-200 dark:border-rose-800 text-xs text-rose-800 dark:text-rose-200 flex items-start gap-2.5">
            <ShieldAlert className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
            <div>
              <p className="font-bold">Caution: Overriding High Risk AI Flag</p>
              <p className="mt-0.5">
                You are approving payment for 100 units while warehouse received only 95 units. This will expose ₹2,95,000 to potential overpayment. A mandatory justification will be written to the permanent audit log.
              </p>
            </div>
          </div>
        )}

        <div className="bg-slate-50 dark:bg-slate-800/60 p-3.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs space-y-1.5">
          <div className="flex justify-between">
            <span className="text-slate-500">Target Exception:</span>
            <span className="font-semibold text-slate-900 dark:text-slate-100">{exception.title}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Financial Exposure:</span>
            <span className="font-semibold text-rose-600">₹{exception.financialImpact.toLocaleString('en-IN')}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">AI Recommendation:</span>
            <span className="font-medium text-slate-700 dark:text-slate-300">{exception.recommendation}</span>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Mandatory Decision Rationale / ERP Note:
          </label>
          <textarea
            value={reason}
            onChange={(e) => {
              setReason(e.target.value);
              if (error) setError('');
            }}
            rows={3}
            className="w-full text-xs p-3 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-slate-900 dark:focus:ring-slate-100"
            placeholder="Explain why this decision is being taken..."
          />
          {error && <p className="text-xs text-rose-600 mt-1">{error}</p>}
        </div>

        <p className="text-[11px] text-slate-400">
          This decision will be cryptographically timestamped and attached to the transaction timeline.
        </p>
      </div>
    </Modal>
  );
};
