import React, { useState } from 'react';
import { Copy, Check, FileJson, ArrowUpRight } from 'lucide-react';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { Transaction } from '../../types/transaction';
import { generateErpPayload } from '../../utils/erp';

interface ErpExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  transaction: Transaction;
}

export const ErpExportModal: React.FC<ErpExportModalProps> = ({
  isOpen,
  onClose,
  transaction,
}) => {
  const [copied, setCopied] = useState(false);
  const payload = generateErpPayload(transaction);
  const jsonString = JSON.stringify(payload, null, 2);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(jsonString);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      console.warn('Copy failed:', e);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="ERP-Ready Structured Business Record"
      subtitle="Canonical transaction data formatted for automated SAP S/4HANA & Oracle NetSuite ingestion."
      maxWidth="2xl"
      footer={
        <div className="flex items-center justify-between w-full">
          <div className="flex items-center gap-2 text-xs text-slate-500 font-mono">
            <span>Standard: SAP_S4HANA_V2</span>
            <span>•</span>
            <span>Status: {transaction.status}</span>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={onClose}>
              Close
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={handleCopy}
              leftIcon={copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            >
              {copied ? 'Copied Payload' : 'Copy ERP JSON'}
            </Button>
          </div>
        </div>
      }
    >
      <div className="space-y-4">
        <div className="bg-slate-900 text-slate-100 rounded-lg p-4 font-mono text-xs overflow-x-auto max-h-96 border border-slate-800">
          <pre>{jsonString}</pre>
        </div>

        <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300">
          <p className="font-semibold text-slate-900 dark:text-slate-100 mb-1">
            Reconciliation & Posting Logic
          </p>
          <p>
            When approved, physical variance (-5 units) generates an automatic Credit Memo
            Request in the accounts payable ledger. When held, payment release flags remain locked in ERP.
          </p>
        </div>
      </div>
    </Modal>
  );
};
