import React from 'react';
import { FileText, CheckCircle2, ShieldCheck, Tag, Building2, Calendar, Hash } from 'lucide-react';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { BusinessDocument } from '../../types/document';
import { ConfidenceTag } from '../ui/ConfidenceTag';

interface SourceDocumentModalProps {
  isOpen: boolean;
  onClose: () => void;
  document: BusinessDocument | null;
}

export const SourceDocumentModal: React.FC<SourceDocumentModalProps> = ({
  isOpen,
  onClose,
  document,
}) => {
  if (!document) return null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={
        <div className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
          <span>Source Document: {document.fileName}</span>
        </div>
      }
      subtitle={`Type: ${document.type} • Reference #${document.documentNumber} • Vendor: ${document.vendor}`}
      maxWidth="2xl"
      footer={
        <div className="flex items-center justify-between w-full">
          <ConfidenceTag score={document.confidenceScores.overall} />
          <Button variant="secondary" size="sm" onClick={onClose}>
            Close Document
          </Button>
        </div>
      }
    >
      <div className="space-y-5">
        {/* Document Metadata Header */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 dark:bg-slate-800/60 p-3.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs">
          <div>
            <span className="text-slate-500 block">Doc Number</span>
            <span className="font-semibold text-slate-900 dark:text-slate-100">{document.documentNumber}</span>
          </div>
          <div>
            <span className="text-slate-500 block">Document Date</span>
            <span className="font-semibold text-slate-900 dark:text-slate-100">{document.documentDate}</span>
          </div>
          <div>
            <span className="text-slate-500 block">Status</span>
            <span className="font-semibold text-emerald-600 dark:text-emerald-400">{document.processingStatus}</span>
          </div>
          <div>
            <span className="text-slate-500 block">Total Value</span>
            <span className="font-bold text-slate-900 dark:text-slate-100">
              ₹{document.extractedFields.total.toLocaleString('en-IN')}
            </span>
          </div>
        </div>

        {/* Pattern Recognition & DNA */}
        {document.patternMatch && (
          <div className="p-3 bg-indigo-50/50 dark:bg-indigo-950/30 rounded-lg border border-indigo-200 dark:border-indigo-800 text-xs">
            <div className="flex items-center justify-between font-semibold text-indigo-900 dark:text-indigo-200 mb-1">
              <span>Layout Pattern: {document.patternMatch.patternName}</span>
              <span className="text-[11px] bg-indigo-100 dark:bg-indigo-900 px-2 py-0.5 rounded">
                Known Template DNA
              </span>
            </div>
            <p className="text-slate-600 dark:text-slate-300">{document.patternMatch.semanticMappingSummary}</p>
          </div>
        )}

        {/* Line Items Table */}
        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
            Normalized Line Items ({document.extractedFields.lineItems.length})
          </h4>
          <div className="border border-slate-200 dark:border-slate-700 rounded-lg overflow-hidden">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold">
                <tr>
                  <th className="p-2.5">Item Description</th>
                  <th className="p-2.5 text-right">Quantity</th>
                  <th className="p-2.5 text-right">Unit Price</th>
                  <th className="p-2.5 text-right">Line Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {document.extractedFields.lineItems.map((item, idx) => (
                  <tr key={idx} className="bg-white dark:bg-slate-900">
                    <td className="p-2.5 font-medium text-slate-900 dark:text-slate-100">{item.description}</td>
                    <td className="p-2.5 text-right font-mono font-bold text-slate-900 dark:text-slate-100">
                      {item.quantity} units
                    </td>
                    <td className="p-2.5 text-right font-mono">₹{item.unitPrice.toLocaleString('en-IN')}</td>
                    <td className="p-2.5 text-right font-mono font-semibold">
                      ₹{item.lineTotal.toLocaleString('en-IN')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Raw Text Snippet / Ground Truth Proof */}
        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
            OCR Raw Ground Truth Snippet
          </h4>
          <div className="bg-slate-950 text-slate-300 p-3 rounded-lg font-mono text-xs border border-slate-800">
            {document.rawTextSnippet ||
              `[GROUND TRUTH EXTRACT]\nDoc: ${document.documentNumber}\nVendor: ${document.vendor}\nCustomer: ${document.customer}\nLine: 100 Laptops @ Rs 50,000\nTotal: Rs 59,00,000`}
          </div>
        </div>
      </div>
    </Modal>
  );
};
