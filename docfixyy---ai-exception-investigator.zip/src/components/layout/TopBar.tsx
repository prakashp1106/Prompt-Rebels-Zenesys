import React from 'react';
import {
  FileText,
  RotateCcw,
  Sparkles,
  UserCheck,
  Building2,
  FileCheck2,
} from 'lucide-react';
import { useStore } from '../../hooks/useStore';

interface TopBarProps {
  currentTab: 'dashboard' | 'documents' | 'investigation' | 'recurring';
  onSelectTab: (tab: 'dashboard' | 'documents' | 'investigation' | 'recurring') => void;
  onOpenErpModal?: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({ currentTab, onSelectTab, onOpenErpModal }) => {
  const [state, store] = useStore();
  const { currentUser, organization } = state;

  return (
    <header className="sticky top-0 z-40 w-full bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Brand Wordmark (Single line, pure typography) */}
        <div className="flex items-center gap-3 shrink-0">
          <div
            onClick={() => onSelectTab('dashboard')}
            className="flex items-center gap-2 cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-lg bg-slate-900 dark:bg-white text-white dark:text-slate-900 flex items-center justify-center font-black tracking-tight text-sm shadow-xs">
              DF
            </div>
            <span className="font-bold tracking-tight text-lg text-slate-900 dark:text-slate-100 uppercase">
              DocFixyy
            </span>
          </div>
        </div>

        {/* Zone 2: 4-5 Navigation Links */}
        <nav className="hidden md:flex items-center gap-1">
          <button
            onClick={() => onSelectTab('dashboard')}
            className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
              currentTab === 'dashboard'
                ? 'bg-slate-100 text-slate-900 dark:bg-slate-800 dark:text-white font-semibold'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => onSelectTab('documents')}
            className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
              currentTab === 'documents'
                ? 'bg-slate-100 text-slate-900 dark:bg-slate-800 dark:text-white font-semibold'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            Documents
          </button>
          <button
            onClick={() => onSelectTab('investigation')}
            className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              currentTab === 'investigation'
                ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 font-semibold shadow-xs'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Investigation</span>
            <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
          </button>
          <button
            onClick={() => onSelectTab('recurring')}
            className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
              currentTab === 'recurring'
                ? 'bg-slate-100 text-slate-900 dark:bg-slate-800 dark:text-white font-semibold'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            Recurring Issues
          </button>
        </nav>

        {/* Zone 3: 1-2 Primary Actions & User Role Switcher */}
        <div className="flex items-center gap-2.5 shrink-0">
          {/* Quick Demo Reset */}
          <button
            onClick={() => store.resetToSeededDemo()}
            className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200 rounded-md border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60"
            title="Reset to Master Hackathon Demo Transaction"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Demo</span>
          </button>

          {/* User Profile / Role Switch */}
          <div className="flex items-center gap-2 pl-2 border-l border-slate-200 dark:border-slate-700">
            <div className="text-right hidden xl:block">
              <div className="text-xs font-semibold text-slate-900 dark:text-slate-100 leading-tight">
                {currentUser.name}
              </div>
              <div className="text-[10px] text-slate-500 font-mono leading-tight">
                {currentUser.role} • {organization.name.split(' ')[0]}
              </div>
            </div>

            <div className="w-8 h-8 rounded-full bg-slate-800 text-white flex items-center justify-center text-xs font-bold ring-2 ring-slate-200 dark:ring-slate-700 overflow-hidden">
              {currentUser.avatarUrl ? (
                <img
                  src={currentUser.avatarUrl}
                  alt={currentUser.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                currentUser.name.charAt(0)
              )}
            </div>

            {/* Quick role selector for testing human review flow */}
            <select
              value={currentUser.id}
              onChange={(e) => store.switchUser(e.target.value)}
              className="text-xs font-medium bg-slate-100 dark:bg-slate-800 border-none rounded py-1 px-1.5 text-slate-700 dark:text-slate-300 focus:outline-none cursor-pointer"
              title="Switch user role"
            >
              <option value="user-sarah">Finance (Sarah)</option>
              <option value="user-david">Procurement (David)</option>
              <option value="user-priya">Admin (Priya)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Mobile nav row */}
      <div className="md:hidden flex items-center justify-around px-2 py-2 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs">
        <button
          onClick={() => onSelectTab('dashboard')}
          className={`py-1 px-2 rounded ${currentTab === 'dashboard' ? 'font-bold text-slate-900 dark:text-white' : 'text-slate-500'}`}
        >
          Dashboard
        </button>
        <button
          onClick={() => onSelectTab('documents')}
          className={`py-1 px-2 rounded ${currentTab === 'documents' ? 'font-bold text-slate-900 dark:text-white' : 'text-slate-500'}`}
        >
          Documents
        </button>
        <button
          onClick={() => onSelectTab('investigation')}
          className={`py-1 px-2 rounded flex items-center gap-1 ${currentTab === 'investigation' ? 'font-bold text-amber-600 dark:text-amber-400' : 'text-slate-500'}`}
        >
          <Sparkles className="w-3 h-3" />
          <span>Investigation</span>
        </button>
        <button
          onClick={() => onSelectTab('recurring')}
          className={`py-1 px-2 rounded ${currentTab === 'recurring' ? 'font-bold text-slate-900 dark:text-white' : 'text-slate-500'}`}
        >
          Recurring
        </button>
      </div>
    </header>
  );
};
