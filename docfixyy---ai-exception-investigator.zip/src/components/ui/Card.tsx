import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  variant?: 'default' | 'muted' | 'highlight' | 'danger' | 'warning' | 'ai';
  title?: React.ReactNode;
  subtitle?: string;
  action?: React.ReactNode;
  footer?: React.ReactNode;
}

export const Card: React.FC<CardProps> = ({
  children,
  className = '',
  variant = 'default',
  title,
  subtitle,
  action,
  footer,
}) => {
  const variantClasses = {
    default: 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-sm',
    muted: 'bg-slate-50 dark:bg-slate-900/50 border-slate-200 dark:border-slate-800',
    highlight: 'bg-indigo-50/40 dark:bg-indigo-950/20 border-indigo-200 dark:border-indigo-800/60 shadow-sm',
    danger: 'bg-rose-50/30 dark:bg-rose-950/20 border-rose-200 dark:border-rose-800/60 shadow-sm',
    warning: 'bg-amber-50/30 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800/60 shadow-sm',
    ai: 'bg-slate-900 text-slate-100 dark:bg-slate-950 border-slate-800 shadow-md',
  };

  return (
    <div className={`rounded-xl border p-5 md:p-6 transition-all ${variantClasses[variant]} ${className}`}>
      {(title || action || subtitle) && (
        <div className="flex items-start justify-between gap-4 mb-4 pb-3 border-b border-slate-100 dark:border-slate-800/80">
          <div>
            {typeof title === 'string' ? (
              <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100 tracking-tight">{title}</h3>
            ) : (
              title
            )}
            {subtitle && <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{subtitle}</p>}
          </div>
          {action && <div className="shrink-0">{action}</div>}
        </div>
      )}
      <div>{children}</div>
      {footer && (
        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
          {footer}
        </div>
      )}
    </div>
  );
};
