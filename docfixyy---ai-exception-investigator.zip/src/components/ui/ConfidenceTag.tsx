import React from 'react';
import { Sparkles, ShieldCheck, AlertCircle } from 'lucide-react';
import { formatConfidenceBadge } from '../../utils/formatting';

interface ConfidenceTagProps {
  score: number; // 0.0 to 1.0
  labelPrefix?: string;
  showIcon?: boolean;
  size?: 'sm' | 'md';
}

export const ConfidenceTag: React.FC<ConfidenceTagProps> = ({
  score,
  labelPrefix = 'AI Confidence',
  showIcon = true,
  size = 'md',
}) => {
  const badge = formatConfidenceBadge(score);

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-md border font-medium ${badge.bg} ${badge.color} ${
        size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs'
      }`}
      title={`${labelPrefix}: ${(score * 100).toFixed(0)}% grounded certainty`}
    >
      {showIcon && (
        score >= 0.85 ? (
          <Sparkles className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
        ) : score >= 0.7 ? (
          <ShieldCheck className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
        ) : (
          <AlertCircle className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
        )
      )}
      <span>
        {labelPrefix}: {badge.label}
      </span>
    </span>
  );
};
