import React from 'react';
import { ShieldAlert, AlertTriangle, CheckCircle, Info } from 'lucide-react';
import { RiskAssessment } from '../../types/transaction';
import { getRiskLevelBadge } from '../../utils/formatting';

interface RiskGaugeProps {
  assessment: RiskAssessment;
  compact?: boolean;
}

export const RiskGauge: React.FC<RiskGaugeProps> = ({ assessment, compact = false }) => {
  const { score, level, factors, summary } = assessment;
  const badge = getRiskLevelBadge(level);

  // SVG Gauge calculations
  const radius = 38;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  const strokeColor =
    level === 'CRITICAL'
      ? '#f43f5e'
      : level === 'HIGH'
      ? '#f59e0b'
      : level === 'MEDIUM'
      ? '#eab308'
      : '#10b981';

  if (compact) {
    return (
      <div className="flex items-center gap-3">
        <div className="relative w-12 h-12 flex items-center justify-center">
          <svg className="w-12 h-12 -rotate-90" viewBox="0 0 100 100">
            <circle
              cx="50"
              cy="50"
              r={radius}
              className="stroke-slate-200 dark:stroke-slate-800"
              strokeWidth="10"
              fill="transparent"
            />
            <circle
              cx="50"
              cy="50"
              r={radius}
              stroke={strokeColor}
              strokeWidth="10"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              fill="transparent"
            />
          </svg>
          <span className="absolute text-xs font-bold text-slate-900 dark:text-slate-100">{score}</span>
        </div>
        <div>
          <span className={`inline-block px-2 py-0.5 text-xs font-bold rounded ${badge.bg}`}>
            {level}
          </span>
          <p className="text-[11px] text-slate-500 mt-0.5">Deterministic Risk</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-slate-900 text-white rounded-xl p-5 border border-slate-800 shadow-md">
      <div className="flex items-center justify-between gap-4 mb-4 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-amber-400" />
          <h4 className="text-sm font-semibold uppercase tracking-wider text-slate-200">Deterministic Risk Engine</h4>
        </div>
        <span className={`px-2.5 py-1 text-xs font-bold rounded-md uppercase tracking-wider ${badge.bg}`}>
          {level} RISK ({score}/100)
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
        {/* Circle Meter */}
        <div className="md:col-span-4 flex flex-col items-center justify-center py-2">
          <div className="relative w-28 h-28 flex items-center justify-center">
            <svg className="w-28 h-28 -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r={radius}
                className="stroke-slate-800"
                strokeWidth="8"
                fill="transparent"
              />
              <circle
                cx="50"
                cy="50"
                r={radius}
                stroke={strokeColor}
                strokeWidth="8"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                fill="transparent"
              />
            </svg>
            <div className="absolute text-center">
              <span className="text-2xl font-black text-white">{score}</span>
              <span className="text-[10px] block uppercase font-medium text-slate-400">/ 100</span>
            </div>
          </div>
          <p className="text-xs text-slate-400 mt-2 text-center font-mono">Calibrated in Code</p>
        </div>

        {/* Factors Breakdown */}
        <div className="md:col-span-8 space-y-2.5">
          <p className="text-xs font-medium text-slate-300 mb-2">{summary}</p>
          <div className="space-y-1.5">
            {factors.map((factor, idx) => (
              <div
                key={idx}
                className={`flex items-center justify-between text-xs p-2 rounded border transition-colors ${
                  factor.triggered
                    ? 'bg-slate-800/80 border-amber-500/40 text-slate-200'
                    : 'bg-slate-950/40 border-slate-800/60 text-slate-400'
                }`}
              >
                <div className="flex items-center gap-2">
                  {factor.triggered ? (
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  ) : (
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  )}
                  <span>{factor.name}</span>
                </div>
                <span
                  className={`font-mono font-medium ${
                    factor.triggered ? 'text-amber-400' : 'text-slate-500'
                  }`}
                >
                  +{factor.scoreContribution} pts
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
