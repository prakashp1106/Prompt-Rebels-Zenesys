import React from 'react';
import {
  AlertTriangle,
  ShieldAlert,
  TrendingUp,
  FileCheck2,
  Clock,
  ArrowRight,
  Sparkles,
  Layers,
  Building2,
  FileText,
  CheckCircle2,
  HelpCircle,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
  PieChart,
  Pie,
} from 'recharts';
import { useStore } from '../hooks/useStore';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { formatCurrency } from '../utils/formatting';

interface DashboardProps {
  onNavigateToInvestigation: () => void;
  onNavigateToDocuments: () => void;
  onNavigateToRecurring: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  onNavigateToInvestigation,
  onNavigateToDocuments,
  onNavigateToRecurring,
}) => {
  const [state] = useStore();
  const { transactions, recurringPatterns, currentUser, organization } = state;
  const transaction = transactions[0];
  const exception = transaction?.exceptions[0];

  const chartData = [
    { name: 'Qty Mismatch', count: 12, color: '#f43f5e' },
    { name: 'Price Variance', count: 7, color: '#f59e0b' },
    { name: 'Missing POD/GRN', count: 5, color: '#6366f1' },
    { name: 'Tax/GST Split', count: 3, color: '#10b981' },
    { name: 'Duplicate Slip', count: 2, color: '#8b5cf6' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Welcome Greeting */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-mono font-semibold uppercase tracking-wider text-slate-500">
            {organization.name} • Workspace
          </span>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 tracking-tight mt-0.5">
            Good morning, {currentUser.role} Team.
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Here's what needs your attention today across 3-way matching and multi-format document reconciliation.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="md"
            onClick={onNavigateToDocuments}
            leftIcon={<Layers className="w-4 h-4" />}
          >
            Multi-Format Demo
          </Button>
          <Button
            variant="primary"
            size="md"
            onClick={onNavigateToInvestigation}
            rightIcon={<ArrowRight className="w-4 h-4" />}
          >
            Investigate Active Issue
          </Button>
        </div>
      </div>

      {/* ─────────────────────────────────────────────────────────────
          STAT CARDS ROW
         ───────────────────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Open Exceptions</span>
            <AlertTriangle className="w-4 h-4 text-rose-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-slate-100">1</span>
            <span className="text-xs text-rose-600 font-medium">Critical focus</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">₹2,95,000 unverified value</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">High Risk</span>
            <ShieldAlert className="w-4 h-4 text-amber-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-amber-600">82 / 100</span>
            <span className="text-xs text-amber-600 font-bold">HIGH</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Deterministic calibrated risk</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Recurring Issues</span>
            <TrendingUp className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-slate-100">12 Cases</span>
            <span className="text-xs text-rose-600 font-semibold">Increasing</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">38% of historic exceptions</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Pending Review</span>
            <Clock className="w-4 h-4 text-slate-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-slate-100">1 Transaction</span>
            <span className="text-xs text-amber-600 font-medium">Actionable</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Human decision required</p>
        </div>
      </div>

      {/* ─────────────────────────────────────────────────────────────
          MAIN NEEDS ATTENTION HIGHLIGHT
         ───────────────────────────────────────────────────────────── */}
      <Card
        variant="warning"
        title={
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-rose-600" />
              <span className="text-rose-950 dark:text-rose-200 font-bold">Needs Immediate Attention</span>
            </div>
            <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-rose-600 text-white">
              PRIORITY: HIGH
            </span>
          </div>
        }
        subtitle="Unresolved 3-way matching discrepancy requiring Procurement and Finance sign-off"
      >
        <div className="space-y-4">
          <div className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-amber-200 dark:border-amber-800 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xs">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-slate-900 dark:text-slate-100">
                  {transaction.invoiceNumber} • {transaction.vendor}
                </span>
                <Badge variant="danger" size="sm">Quantity Mismatch</Badge>
              </div>
              <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                Invoice bills for 100 units while warehouse GRN verifies receipt of only 95 units.
              </p>
              <p className="text-xs text-slate-500">
                Discrepancy: 5 units • Exposure: <strong className="text-rose-600 font-mono">₹2,95,000</strong> • Owner: <strong className="text-slate-700 dark:text-slate-300">Procurement Team</strong>
              </p>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <div className="text-right hidden sm:block">
                <span className="text-xs text-slate-500 block">Risk Score</span>
                <span className="text-lg font-black text-amber-600">82 / 100</span>
              </div>
              <Button
                variant="primary"
                size="md"
                onClick={onNavigateToInvestigation}
                rightIcon={<ArrowRight className="w-4 h-4" />}
              >
                Investigate Exception
              </Button>
            </div>
          </div>
        </div>
      </Card>

      {/* ─────────────────────────────────────────────────────────────
          CHARTS & HISTORICAL PATTERNS
         ───────────────────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Exception Distribution Chart (7 cols) */}
        <div className="lg:col-span-7">
          <Card
            title="Historical Exception Type Distribution"
            subtitle="Frequency breakdown across last 90 days of vendor transactions"
          >
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} layout="vertical" margin={{ top: 5, right: 30, left: 40, bottom: 5 }}>
                  <XAxis type="number" hide />
                  <YAxis type="category" dataKey="name" tick={{ fontSize: 11, fill: '#64748b' }} width={90} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderRadius: '8px',
                      border: '1px solid #334155',
                      fontSize: '12px',
                      color: '#fff',
                    }}
                  />
                  <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </div>

        {/* Recurring Pattern Spotlight (5 cols) */}
        <div className="lg:col-span-5">
          <Card
            title={
              <div className="flex items-center justify-between w-full">
                <span>Recurring Pattern Spotlight</span>
                <button
                  onClick={onNavigateToRecurring}
                  className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold hover:underline cursor-pointer"
                >
                  View All (4) →
                </button>
              </div>
            }
            subtitle="Systemic business problems identified by DocFixyy"
          >
            <div className="space-y-3">
              {recurringPatterns.slice(0, 2).map((pattern) => (
                <div
                  key={pattern.id}
                  className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2 text-xs"
                >
                  <div className="flex items-center justify-between font-semibold text-slate-900 dark:text-slate-100">
                    <span>{pattern.title}</span>
                    <span className="px-2 py-0.5 bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300 rounded font-bold font-mono">
                      {pattern.occurrenceCount} cases
                    </span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-300 line-clamp-2">
                    {pattern.description}
                  </p>
                  <div className="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-slate-700 text-[11px] text-slate-500">
                    <span>{pattern.percentageOfExceptions}% of total</span>
                    <span className="font-mono text-slate-700 dark:text-slate-300 font-semibold">
                      ₹{pattern.totalFinancialImpact.toLocaleString('en-IN')} exposure
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};
