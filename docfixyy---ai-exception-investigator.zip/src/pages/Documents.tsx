import React, { useState } from 'react';
import {
  UploadCloud,
  FileText,
  CheckCircle2,
  AlertCircle,
  Clock,
  Sparkles,
  ArrowRight,
  Eye,
  Layers,
  FileSpreadsheet,
  Zap,
  RefreshCw,
  FolderOpen,
} from 'lucide-react';
import { useStore } from '../hooks/useStore';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { ConfidenceTag } from '../components/ui/ConfidenceTag';
import { SourceDocumentModal } from '../components/investigation/SourceDocumentModal';
import { BusinessDocument, DocumentType } from '../types/document';
import { SAMPLE_LAYOUT_FORMATS, LayoutSample } from '../utils/normalization';

const PROCESSING_STAGES = [
  'Uploading document...',
  'Reading document with Gemini 3.7...',
  'Understanding visual structure & layout...',
  'Recognizing document pattern & DNA...',
  'Normalizing to universal canonical schema...',
  'Connecting related documents (PO ↔ GRN ↔ Invoice)...',
  'Checking deterministic inconsistencies...',
  'Investigating exception root cause...',
  'Calculating calibrated risk score...',
  'Investigation ready.',
];

export const Documents: React.FC<{ onNavigateToInvestigation: () => void }> = ({
  onNavigateToInvestigation,
}) => {
  const [state, store] = useStore();
  const { documents, currentUser } = state;

  const [selectedDoc, setSelectedDoc] = useState<BusinessDocument | null>(null);
  const [selectedLayoutSample, setSelectedLayoutSample] = useState<LayoutSample>(SAMPLE_LAYOUT_FORMATS[0]);
  const [isProcessingLive, setIsProcessingLive] = useState(false);
  const [currentStageIndex, setCurrentStageIndex] = useState(0);
  const [dragOver, setDragOver] = useState(false);

  const startLiveProcessingSimulation = (docType: DocumentType = 'INVOICE', layoutName: string = 'Modern Corporate') => {
    setIsProcessingLive(true);
    setCurrentStageIndex(0);

    let stage = 0;
    const interval = setInterval(() => {
      stage += 1;
      if (stage < PROCESSING_STAGES.length) {
        setCurrentStageIndex(stage);
      } else {
        clearInterval(interval);
        setTimeout(() => {
          setIsProcessingLive(false);
          // Add or refresh document in store
          onNavigateToInvestigation();
        }, 600);
      }
    }, 450);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      startLiveProcessingSimulation('INVOICE', file.name);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      startLiveProcessingSimulation('INVOICE', e.dataTransfer.files[0].name);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 tracking-tight">
            Document Intelligence Center
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Universal ingestion, pattern recognition, and multi-format canonical normalization.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="md"
            onClick={() => startLiveProcessingSimulation('INVOICE', 'Live Re-scan')}
            leftIcon={<RefreshCw className="w-4 h-4" />}
          >
            Re-run Pipeline
          </Button>
          <Button
            variant="primary"
            size="md"
            onClick={onNavigateToInvestigation}
            rightIcon={<ArrowRight className="w-4 h-4" />}
          >
            Open Investigation
          </Button>
        </div>
      </div>

      {/* ─────────────────────────────────────────────────────────────
          MULTI-STAGE PROCESSING OVERLAY
         ───────────────────────────────────────────────────────────── */}
      {isProcessingLive && (
        <div className="p-6 bg-slate-900 text-white rounded-2xl border border-slate-800 shadow-xl space-y-4 animate-in fade-in">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Sparkles className="w-5 h-5 text-amber-400 animate-spin" />
              <span className="font-bold text-sm tracking-tight text-slate-100">
                AI Document Pipeline In Progress
              </span>
            </div>
            <span className="text-xs font-mono text-slate-400">
              Stage {currentStageIndex + 1} of {PROCESSING_STAGES.length}
            </span>
          </div>

          <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
            <div
              className="bg-amber-400 h-full transition-all duration-300 ease-out"
              style={{ width: `${((currentStageIndex + 1) / PROCESSING_STAGES.length) * 100}%` }}
            />
          </div>

          <p className="text-base font-semibold text-amber-300 font-mono">
            {PROCESSING_STAGES[currentStageIndex]}
          </p>
        </div>
      )}

      {/* ─────────────────────────────────────────────────────────────
          UPLOAD DRAG & DROP ZONE
         ───────────────────────────────────────────────────────────── */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        className={`p-8 md:p-12 rounded-2xl border-2 border-dashed transition-all text-center ${
          dragOver
            ? 'border-slate-900 bg-slate-100 dark:border-slate-100 dark:bg-slate-800/80'
            : 'border-slate-300 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/40 hover:bg-slate-50 dark:hover:bg-slate-900/80'
        }`}
      >
        <div className="max-w-md mx-auto space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center mx-auto text-slate-900 dark:text-slate-100 shadow-xs">
            <UploadCloud className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Drop invoices, purchase orders or GRNs here
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Supports PDF, scanned images, thermal slips, multi-column tax invoices. Automatic layout recognition.
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <label className="cursor-pointer">
              <input
                type="file"
                className="hidden"
                accept=".pdf,.png,.jpg,.jpeg,.tiff"
                onChange={handleFileUpload}
              />
              <span className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 hover:bg-slate-800 transition-colors shadow-xs">
                <FolderOpen className="w-4 h-4" />
                Upload Documents
              </span>
            </label>

            <Button
              variant="outline"
              size="sm"
              onClick={() => startLiveProcessingSimulation('INVOICE', 'Demo Scan')}
            >
              Test with Master Demo Transaction
            </Button>
          </div>
        </div>
      </div>

      {/* ─────────────────────────────────────────────────────────────
          SECTION 32 SHOWCASE: MULTI-FORMAT DOCUMENT NORMALIZATION DEMO
          "Different documents. One business language."
         ───────────────────────────────────────────────────────────── */}
      <Card
        title={
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            <span>Universal Document Normalization & Layout Intelligence</span>
          </div>
        }
        subtitle="Witness how DocFixyy understands visually diverse invoice formats and maps them into one canonical business truth"
      >
        <div className="p-4 bg-slate-900 text-white rounded-xl mb-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-widest text-indigo-400 font-mono">
              CORE VALUE PROPOSITION
            </span>
            <h3 className="text-lg font-bold text-slate-100 mt-0.5">
              “Different documents. One business language.”
            </h3>
            <p className="text-xs text-slate-400 mt-1 max-w-xl">
              Vendors call document numbers <code className="text-indigo-300">Bill No.</code>, <code className="text-indigo-300">Invoice #</code>, or <code className="text-indigo-300">Tax Invoice No.</code>. DocFixyy understands semantic meaning—not rigid templates.
            </p>
          </div>

          {/* Selector Tabs for the 3 Formats */}
          <div className="flex bg-slate-800 p-1 rounded-lg shrink-0 gap-1">
            {SAMPLE_LAYOUT_FORMATS.map((sample) => (
              <button
                key={sample.id}
                onClick={() => setSelectedLayoutSample(sample)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                  selectedLayoutSample.id === sample.id
                    ? 'bg-indigo-600 text-white font-bold shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {sample.category}
              </button>
            ))}
          </div>
        </div>

        {/* 2-Column Split: Raw Layout Format vs Normalized Canonical Schema */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left: Raw Document Fields */}
          <div className="lg:col-span-6 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-2">
              <span className="text-xs font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider">
                Raw Layout ({selectedLayoutSample.name})
              </span>
              <Badge variant="neutral" size="sm">Source Format</Badge>
            </div>
            <p className="text-xs text-slate-500">{selectedLayoutSample.layoutDescription}</p>

            <div className="bg-white dark:bg-slate-950 p-3 rounded-lg border border-slate-200 dark:border-slate-800 font-mono text-xs space-y-2 text-slate-700 dark:text-slate-300">
              <div className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 uppercase">
                Raw Header Aliases:
              </div>
              {Object.entries(selectedLayoutSample.rawSampleData.header).map(([key, val]) => (
                <div key={key} className="flex justify-between py-0.5 border-b border-slate-100 dark:border-slate-900">
                  <span className="text-slate-400">{key}:</span>
                  <span className="font-semibold text-slate-900 dark:text-slate-100 text-right">{val}</span>
                </div>
              ))}
              <div className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 uppercase mt-2">
                Raw Summary Aliases:
              </div>
              {Object.entries(selectedLayoutSample.rawSampleData.summary).map(([key, val]) => (
                <div key={key} className="flex justify-between py-0.5 border-b border-slate-100 dark:border-slate-900">
                  <span className="text-slate-400">{key}:</span>
                  <span className="font-semibold text-slate-900 dark:text-slate-100 text-right">{val}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Universal Canonical Schema */}
          <div className="lg:col-span-6 p-4 rounded-xl border border-indigo-200 dark:border-indigo-800 bg-indigo-50/30 dark:bg-indigo-950/20 space-y-3">
            <div className="flex items-center justify-between border-b border-indigo-200 dark:border-indigo-800 pb-2">
              <div className="flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <span className="text-xs font-bold text-indigo-950 dark:text-indigo-100 uppercase tracking-wider">
                  Universal Canonical Schema
                </span>
              </div>
              <Badge variant="success" size="sm">100% Normalized</Badge>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300">
              All different terminology mapped into one standard enterprise object.
            </p>

            <div className="bg-slate-900 text-emerald-300 p-3 rounded-lg border border-slate-800 font-mono text-xs overflow-x-auto space-y-1">
              <p className="text-slate-400">// Unified Canonical Output</p>
              <p>documentType: "INVOICE"</p>
              <p>documentNumber: "INV-5001" <span className="text-slate-500">// &lt;- from "{selectedLayoutSample.docNumberField}"</span></p>
              <p>vendor: "ABC Suppliers" <span className="text-slate-500">// &lt;- from "{selectedLayoutSample.vendorField}"</span></p>
              <p>customer: "ABC Electronics Pvt. Ltd."</p>
              <p>referenceNumbers: ["PO-1024"]</p>
              <p>lineItems: [{`quantity: 100, unitPrice: 50000, lineTotal: 5000000`}]</p>
              <p>subtotal: 5000000</p>
              <p>tax: 900000</p>
              <p>total: 5900000 <span className="text-slate-500">// &lt;- from "{selectedLayoutSample.totalField}"</span></p>
            </div>
          </div>
        </div>
      </Card>

      {/* ─────────────────────────────────────────────────────────────
          DOCUMENT LIST TABLE
         ───────────────────────────────────────────────────────────── */}
      <Card
        title={
          <div className="flex items-center justify-between w-full">
            <span>Ingested Documents ({documents.length})</span>
            <span className="text-xs font-normal text-slate-500">Live Workspace Repository</span>
          </div>
        }
        subtitle="All normalized documents with extraction confidence, DNA profiles, and transaction status"
      >
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 uppercase tracking-wider font-semibold">
              <tr>
                <th className="p-3">Document</th>
                <th className="p-3">Type</th>
                <th className="p-3">Vendor / Entity</th>
                <th className="p-3">Total Value</th>
                <th className="p-3">Confidence</th>
                <th className="p-3">Processing Status</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
              {documents.map((doc) => (
                <tr key={doc.id} className="hover:bg-slate-50 dark:hover:bg-slate-850 transition-colors">
                  <td className="p-3">
                    <div className="flex items-center gap-2.5">
                      <FileText className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
                      <div>
                        <span className="font-semibold text-slate-900 dark:text-slate-100 block">
                          {doc.fileName}
                        </span>
                        <span className="text-[11px] text-slate-400 font-mono">
                          Ref #{doc.documentNumber} • {doc.documentDate}
                        </span>
                      </div>
                    </div>
                  </td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded font-mono font-medium text-[11px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      {doc.type}
                    </span>
                  </td>
                  <td className="p-3 font-medium text-slate-900 dark:text-slate-100">{doc.vendor}</td>
                  <td className="p-3 font-mono font-semibold text-slate-900 dark:text-slate-100">
                    ₹{doc.extractedFields.total.toLocaleString('en-IN')}
                  </td>
                  <td className="p-3">
                    <ConfidenceTag score={doc.confidenceScores.overall} size="sm" />
                  </td>
                  <td className="p-3">
                    <span
                      className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold ${
                        doc.processingStatus === 'PROCESSED'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : doc.processingStatus === 'REVIEW_REQUIRED'
                          ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                          : 'bg-slate-100 text-slate-800'
                      }`}
                    >
                      {doc.processingStatus}
                    </span>
                  </td>
                  <td className="p-3 text-right">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedDoc(doc)}
                      leftIcon={<Eye className="w-3.5 h-3.5" />}
                    >
                      Inspect
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Inspect Modal */}
      <SourceDocumentModal
        isOpen={Boolean(selectedDoc)}
        onClose={() => setSelectedDoc(null)}
        document={selectedDoc}
      />
    </div>
  );
};
