import React, { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  FileText,
  Clock,
  ShieldAlert,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Users,
  HelpCircle,
  FileSearch,
  Check,
  PauseCircle,
  XCircle,
  FileJson,
  Building2,
  Hash,
  Layers,
  ArrowUpRight,
  ExternalLink,
} from 'lucide-react';
import { useStore } from '../hooks/useStore';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { ConfidenceTag } from '../components/ui/ConfidenceTag';
import { RiskGauge } from '../components/ui/RiskGauge';
import { SourceDocumentModal } from '../components/investigation/SourceDocumentModal';
import { DecisionModal } from '../components/investigation/DecisionModal';
import { ErpExportModal } from '../components/investigation/ErpExportModal';
import { BusinessDocument } from '../types/document';
import { InvestigationException } from '../types/exception';

export const Investigation: React.FC = () => {
  const [state] = useStore();
  const { transactions, documents, recurringPatterns, auditLogs, currentUser } = state;
  const transaction = transactions[0]; // Master hackathon transaction
  const exception: InvestigationException = transaction?.exceptions[0];

  const [selectedDocForModal, setSelectedDocForModal] = useState<BusinessDocument | null>(null);
  const [decisionModalOpen, setDecisionModalOpen] = useState(false);
  const [targetDecision, setTargetDecision] = useState<'APPROVED' | 'HELD' | 'REJECTED'>('HELD');
  const [erpModalOpen, setErpModalOpen] = useState(false);

  // Find linked documents
  const poDoc = documents.find((d) => d.id === 'doc-po-1024' || d.type === 'PURCHASE_ORDER');
  const grnDoc = documents.find((d) => d.id === 'doc-grn-9021' || d.type === 'GRN');
  const invDoc = documents.find((d) => d.id === 'doc-inv-5001' || d.type === 'INVOICE');

  const recurringPattern = recurringPatterns.find((p) => p.type === exception?.type) || recurringPatterns[0];

  const openDecisionDialog = (type: 'APPROVED' | 'HELD' | 'REJECTED') => {
    setTargetDecision(type);
    setDecisionModalOpen(true);
  };

  const handleOpenSourceDoc = (docIdOrType: string) => {
    const found = documents.find(
      (d) => d.id === docIdOrType || d.type === docIdOrType || d.documentNumber === docIdOrType
    );
    if (found) setSelectedDocForModal(found);
    else if (invDoc) setSelectedDocForModal(invDoc);
  };

  if (!transaction || !exception) {
    return (
      <div className="p-8 text-center text-slate-500">
        <p>No active investigation loaded.</p>
      </div>
    );
  }

  const isDecisionRecorded = exception.decision !== 'PENDING';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* ─────────────────────────────────────────────────────────────
          PAGE HEADER: Title, Risk Banner, ERP Button, Status
         ───────────────────────────────────────────────────────────── */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 text-xs font-mono font-bold bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 rounded-md">
              INVESTIGATION #{transaction.invoiceNumber}
            </span>
            <span className="text-xs text-slate-500 font-mono">
              Txn Ref: {transaction.transactionCode}
            </span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 mt-2 tracking-tight">
            Cross-Document Discrepancy Investigation
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Vendor: <strong className="text-slate-800 dark:text-slate-200">{transaction.vendor}</strong> • PO: {transaction.poNumber} • GRN: {transaction.grnNumber}
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <Button
            variant="outline"
            size="md"
            onClick={() => setErpModalOpen(true)}
            leftIcon={<FileJson className="w-4 h-4 text-slate-600 dark:text-slate-300" />}
          >
            ERP Record
          </Button>

          {isDecisionRecorded ? (
            <div
              className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 ${
                exception.decision === 'HELD'
                  ? 'bg-amber-500 text-slate-950 border border-amber-600'
                  : exception.decision === 'APPROVED'
                  ? 'bg-emerald-600 text-white border border-emerald-700'
                  : 'bg-rose-600 text-white border border-rose-700'
              }`}
            >
              {exception.decision === 'HELD' ? (
                <PauseCircle className="w-4 h-4" />
              ) : exception.decision === 'APPROVED' ? (
                <Check className="w-4 h-4" />
              ) : (
                <XCircle className="w-4 h-4" />
              )}
              <span>STATUS: {exception.decision}</span>
            </div>
          ) : (
            <div className="px-3.5 py-2 bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 rounded-lg text-rose-700 dark:text-rose-300 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 animate-pulse">
              <span className="w-2 h-2 rounded-full bg-rose-500" />
              <span>Action Required</span>
            </div>
          )}
        </div>
      </div>

      {/* ─────────────────────────────────────────────────────────────
          SECTION 1 — BUSINESS TRUTH NARRATIVE
         ───────────────────────────────────────────────────────────── */}
      <div className="bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 shadow-md">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-[11px] font-bold uppercase tracking-widest text-indigo-400 font-mono">
            SECTION 01 • SINGLE BUSINESS TRUTH
          </span>
        </div>
        <p className="text-lg md:text-xl font-medium leading-relaxed text-slate-100">
          “{transaction.businessStory}”
        </p>
        <div className="mt-3 pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>3 Documents Normalized & Reconciled</span>
          </div>
          <span className="font-mono text-slate-400">Detected Overbilling: ₹2,95,000</span>
        </div>
      </div>

      {/* ─────────────────────────────────────────────────────────────
          SECTION 2 — DOCUMENT STORY TIMELINE
         ───────────────────────────────────────────────────────────── */}
      <Card
        title={
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-slate-600 dark:text-slate-400" />
            <span>Document Reconciliation Journey</span>
          </div>
        }
        subtitle="Chronological transaction flow reconstructed across procurement, warehouse, and accounting"
      >
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 relative">
          {/* Step 1: PO */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
            <div className="flex items-center justify-between mb-2">
              <Badge variant="neutral" size="sm">01. ORDER</Badge>
              <span className="text-[11px] font-mono text-slate-400">PO-1024</span>
            </div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">Purchase Order</h4>
            <p className="text-xs text-slate-500 mt-1">100 Laptops authorized @ ₹50,000</p>
            <div className="mt-3 flex items-center justify-between text-xs pt-2 border-t border-slate-200 dark:border-slate-800">
              <span className="text-slate-600 font-mono">100 Units</span>
              <button
                onClick={() => handleOpenSourceDoc('doc-po-1024')}
                className="text-indigo-600 dark:text-indigo-400 font-medium hover:underline text-[11px] cursor-pointer"
              >
                View PO →
              </button>
            </div>
          </div>

          {/* Step 2: GRN */}
          <div className="p-4 rounded-xl border border-amber-300 dark:border-amber-800/80 bg-amber-50/40 dark:bg-amber-950/20">
            <div className="flex items-center justify-between mb-2">
              <Badge variant="warning" size="sm">02. RECEIPT</Badge>
              <span className="text-[11px] font-mono text-amber-700 dark:text-amber-400">GRN-9021</span>
            </div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">Warehouse Receipt</h4>
            <p className="text-xs text-amber-800 dark:text-amber-300 mt-1">Dock 4 scanned 95 units (5 short)</p>
            <div className="mt-3 flex items-center justify-between text-xs pt-2 border-t border-amber-200 dark:border-amber-800/60">
              <span className="text-amber-900 dark:text-amber-200 font-mono font-bold">95 Units</span>
              <button
                onClick={() => handleOpenSourceDoc('doc-grn-9021')}
                className="text-amber-700 dark:text-amber-400 font-medium hover:underline text-[11px] cursor-pointer"
              >
                View GRN →
              </button>
            </div>
          </div>

          {/* Step 3: Invoice */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
            <div className="flex items-center justify-between mb-2">
              <Badge variant="neutral" size="sm">03. BILLING</Badge>
              <span className="text-[11px] font-mono text-slate-400">INV-5001</span>
            </div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">Vendor Invoice</h4>
            <p className="text-xs text-slate-500 mt-1">Billed full PO quota @ ₹59,00,000</p>
            <div className="mt-3 flex items-center justify-between text-xs pt-2 border-t border-slate-200 dark:border-slate-800">
              <span className="text-slate-600 font-mono">100 Units</span>
              <button
                onClick={() => handleOpenSourceDoc('doc-inv-5001')}
                className="text-indigo-600 dark:text-indigo-400 font-medium hover:underline text-[11px] cursor-pointer"
              >
                View Invoice →
              </button>
            </div>
          </div>

          {/* Step 4: Exception */}
          <div className="p-4 rounded-xl border border-rose-300 dark:border-rose-800/80 bg-rose-50/50 dark:bg-rose-950/30">
            <div className="flex items-center justify-between mb-2">
              <Badge variant="danger" size="sm">04. EXCEPTION</Badge>
              <span className="text-[11px] font-mono text-rose-700 dark:text-rose-400 font-bold">MISMATCH</span>
            </div>
            <h4 className="text-sm font-bold text-rose-900 dark:text-rose-200">5-Unit Shortage</h4>
            <p className="text-xs text-rose-700 dark:text-rose-300 mt-1">₹2,95,000 Unverified Billed Value</p>
            <div className="mt-3 flex items-center justify-between text-xs pt-2 border-t border-rose-200 dark:border-rose-800/60">
              <span className="text-rose-800 dark:text-rose-200 font-mono font-bold">+5 Unreceived</span>
              <span className="text-rose-600 font-semibold text-[11px]">Flagged</span>
            </div>
          </div>
        </div>
      </Card>

      {/* ─────────────────────────────────────────────────────────────
          SECTION 3 & 4 — DOCUMENT COMPARISON & EXCEPTION ENGINE
         ───────────────────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Comparison Table (Left 7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <Card
            title={
              <div className="flex items-center justify-between w-full">
                <span>Deterministic Cross-Document Comparison</span>
                <span className="text-xs font-mono font-normal text-slate-500">Pure Code Diff Engine</span>
              </div>
            }
            subtitle="Comparing Purchase Order vs Physical Warehouse GRN vs Vendor Billed Invoice"
          >
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 uppercase tracking-wider font-semibold">
                  <tr>
                    <th className="p-3">Reconciliation Field</th>
                    <th className="p-3">PO (PO-1024)</th>
                    <th className="p-3">GRN (GRN-9021)</th>
                    <th className="p-3">Invoice (INV-5001)</th>
                    <th className="p-3 text-right">Variance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {transaction.comparison.fields.map((field, idx) => (
                    <tr
                      key={idx}
                      className={
                        field.mismatch
                          ? 'bg-rose-50/40 dark:bg-rose-950/20 font-medium'
                          : 'bg-white dark:bg-slate-900'
                      }
                    >
                      <td className="p-3 font-semibold text-slate-900 dark:text-slate-100">
                        {field.label}
                      </td>
                      <td className="p-3 font-mono text-slate-600 dark:text-slate-400">
                        {field.poValue}
                      </td>
                      <td
                        className={`p-3 font-mono ${
                          field.mismatch ? 'font-bold text-amber-700 dark:text-amber-400' : 'text-slate-600 dark:text-slate-400'
                        }`}
                      >
                        {field.grnValue}
                      </td>
                      <td
                        className={`p-3 font-mono ${
                          field.mismatch ? 'font-bold text-rose-700 dark:text-rose-400' : 'text-slate-600 dark:text-slate-400'
                        }`}
                      >
                        {field.invoiceValue}
                      </td>
                      <td className="p-3 text-right">
                        {field.mismatch ? (
                          <span className="inline-block px-2 py-0.5 rounded font-mono font-bold text-[11px] bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
                            {field.delta}
                          </span>
                        ) : (
                          <span className="text-emerald-600 dark:text-emerald-400 font-mono text-[11px]">
                            Match ✓
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="mt-4 p-3 bg-slate-50 dark:bg-slate-800/40 rounded-lg text-xs text-slate-600 dark:text-slate-300 flex items-center justify-between">
              <span>Primary Item: Enterprise ThinkPad Laptops (Core i7 / 16GB RAM)</span>
              <span className="font-mono font-bold text-rose-600">Discrepancy: +5 unreceived units billed</span>
            </div>
          </Card>
        </div>

        {/* Risk Breakdown & Exception Summary (Right 5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <RiskGauge assessment={transaction.riskAssessment} />

          <Card
            variant="danger"
            title={
              <div className="flex items-center gap-2 text-rose-900 dark:text-rose-200">
                <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
                <span>Detected Exception: QUANTITY MISMATCH</span>
              </div>
            }
          >
            <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
              {exception.description}
            </p>

            <div className="mt-3 pt-3 border-t border-rose-200 dark:border-rose-800/60 flex items-center justify-between text-xs">
              <span className="text-slate-500">Unverified Financial Exposure:</span>
              <span className="font-bold font-mono text-rose-700 dark:text-rose-300 text-sm">
                ₹{exception.financialImpact.toLocaleString('en-IN')}
              </span>
            </div>
          </Card>
        </div>
      </div>

      {/* ─────────────────────────────────────────────────────────────
          SECTION 5 & 6 — ROOT CAUSE & RECURRING PROBLEM DETECTION
         ───────────────────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* SECTION 5: ROOT CAUSE ANALYSIS (7 cols) */}
        <div className="lg:col-span-7">
          <Card
            title={
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                  <span>Root Cause Analysis — Why Did This Happen?</span>
                </div>
                <ConfidenceTag score={exception.rootCauseConfidence} />
              </div>
            }
            subtitle="AI investigation grounded strictly in verified cross-document evidence"
          >
            <div className="p-4 bg-indigo-50/50 dark:bg-indigo-950/30 rounded-xl border border-indigo-200 dark:border-indigo-800/60 mb-4">
              <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 leading-relaxed">
                “{exception.rootCause}”
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700">
                <h5 className="font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider text-[11px] mb-2 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Ground Truth Facts (100% Proven)</span>
                </h5>
                <ul className="space-y-1.5 text-slate-600 dark:text-slate-300 list-disc list-inside">
                  {exception.rootCauseFacts.map((fact, i) => (
                    <li key={i}>{fact}</li>
                  ))}
                </ul>
              </div>

              <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700">
                <h5 className="font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider text-[11px] mb-2 flex items-center gap-1.5">
                  <HelpCircle className="w-3.5 h-3.5 text-indigo-600" />
                  <span>AI Business Inferences</span>
                </h5>
                <ul className="space-y-1.5 text-slate-600 dark:text-slate-300 list-disc list-inside">
                  {exception.rootCauseInferences.map((inf, i) => (
                    <li key={i}>{inf}</li>
                  ))}
                </ul>
              </div>
            </div>
          </Card>
        </div>

        {/* SECTION 6: RECURRING PROBLEM DETECTION (5 cols) */}
        <div className="lg:col-span-5">
          <Card
            variant="warning"
            title={
              <div className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-amber-600" />
                <span>Recurring Problem Detection</span>
              </div>
            }
            subtitle="Historical intelligence: This isn't an isolated problem"
          >
            <div className="space-y-4">
              <div className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-amber-200 dark:border-amber-800/80 shadow-xs">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-amber-900 dark:text-amber-200 uppercase tracking-wider">
                    {recurringPattern.title}
                  </span>
                  <span className="px-2 py-0.5 text-xs font-bold bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 rounded">
                    Trend: {recurringPattern.trend}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3 my-3 text-center">
                  <div className="p-2.5 bg-amber-50/60 dark:bg-amber-950/40 rounded-lg border border-amber-200 dark:border-amber-800">
                    <span className="text-2xl font-black text-amber-900 dark:text-amber-200">
                      {recurringPattern.occurrenceCount}
                    </span>
                    <span className="text-[11px] block text-slate-500 font-medium">Similar Cases</span>
                  </div>
                  <div className="p-2.5 bg-amber-50/60 dark:bg-amber-950/40 rounded-lg border border-amber-200 dark:border-amber-800">
                    <span className="text-2xl font-black text-amber-900 dark:text-amber-200">
                      {recurringPattern.percentageOfExceptions}%
                    </span>
                    <span className="text-[11px] block text-slate-500 font-medium">of All Exceptions</span>
                  </div>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300">
                  {recurringPattern.description}
                </p>
              </div>

              <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300">
                <strong className="text-slate-900 dark:text-slate-100 block mb-1">Systemic Recommendation:</strong>
                {recurringPattern.recommendedAction}
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* ─────────────────────────────────────────────────────────────
          SECTION 8 & 9 — EVIDENCE CHAIN & MISSING EVIDENCE
         ───────────────────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Evidence Chain (7 cols) */}
        <div className="lg:col-span-7">
          <Card
            title={
              <div className="flex items-center gap-2">
                <FileSearch className="w-5 h-5 text-slate-700 dark:text-slate-300" />
                <span>Auditable Evidence Chain</span>
              </div>
            }
            subtitle="Every conclusion is directly linked to an inspected source document"
          >
            <div className="space-y-3">
              {exception.evidence.map((item, idx) => (
                <div
                  key={idx}
                  className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 dark:text-slate-100">{item.documentType}</span>
                      <span className="font-mono text-slate-400">({item.documentNumber})</span>
                    </div>
                    <p className="text-slate-600 dark:text-slate-300 font-mono">
                      Field: <strong>{item.field}</strong> → <span className="font-bold text-slate-900 dark:text-white">{item.value}</span>
                    </p>
                    {item.note && <p className="text-[11px] text-slate-500 italic">{item.note}</p>}
                  </div>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleOpenSourceDoc(item.documentId)}
                    rightIcon={<ExternalLink className="w-3.5 h-3.5" />}
                  >
                    Open Source Document
                  </Button>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Missing Evidence & Owner Team (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <Card
            variant="warning"
            title={
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-amber-600" />
                <span>Missing Audit Evidence</span>
              </div>
            }
          >
            {exception.missingEvidence.map((me) => (
              <div key={me.id} className="space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 dark:text-slate-100">{me.title}</span>
                  <Badge variant="warning" size="sm">STATUS: {me.status}</Badge>
                </div>
                <p className="text-slate-600 dark:text-slate-300">{me.impactDescription}</p>
                <p className="text-[11px] text-slate-500">
                  Responsible Party: <strong className="text-slate-700 dark:text-slate-300">{me.responsibleParty}</strong>
                </p>
              </div>
            ))}
          </Card>

          <Card
            title={
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-indigo-600" />
                <span>Responsible Owner Team</span>
              </div>
            }
          >
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="font-bold text-base text-indigo-900 dark:text-indigo-300">
                {exception.ownerTeam} Team
              </span>
              <Badge variant="ai" size="sm">Priority: {exception.priority}</Badge>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300">{exception.ownerReason}</p>
          </Card>
        </div>
      </div>

      {/* ─────────────────────────────────────────────────────────────
          SECTION 11 & 12 — RECOMMENDATION & WHAT-IF IMPACT SCENARIOS
         ───────────────────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Recommendation (5 cols) */}
        <div className="lg:col-span-5">
          <Card
            variant="highlight"
            title={
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                <span>AI Recommended Next Action</span>
              </div>
            }
          >
            <div className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-indigo-200 dark:border-indigo-800 shadow-xs space-y-2">
              <p className="text-sm font-bold text-slate-900 dark:text-slate-100 leading-snug">
                “{exception.recommendation}”
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Action: Issue Discrepancy Notice to ABC Suppliers requesting a revised invoice for ₹56,05,000 (95 units) or vendor credit note.
              </p>
            </div>
          </Card>
        </div>

        {/* What-If Impact Engine (7 cols) */}
        <div className="lg:col-span-7">
          <Card
            title={
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center gap-2">
                  <Layers className="w-5 h-5 text-slate-700 dark:text-slate-300" />
                  <span>What-If Downstream Impact Engine</span>
                </div>
                <Badge variant="ai" size="sm">AI-Generated Estimate</Badge>
              </div>
            }
            subtitle="Deterministic financial simulation of downstream consequences"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="p-3.5 bg-rose-50/60 dark:bg-rose-950/30 rounded-xl border border-rose-200 dark:border-rose-800 space-y-1.5">
                <div className="flex items-center justify-between font-bold text-rose-900 dark:text-rose-200">
                  <span>IF APPROVED AS-IS</span>
                  <span className="text-[10px] text-rose-600 uppercase font-mono">High Risk</span>
                </div>
                <p className="text-slate-700 dark:text-slate-300 leading-relaxed">{exception.whatIfApproved}</p>
              </div>

              <div className="p-3.5 bg-emerald-50/60 dark:bg-emerald-950/30 rounded-xl border border-emerald-200 dark:border-emerald-800 space-y-1.5">
                <div className="flex items-center justify-between font-bold text-emerald-900 dark:text-emerald-200">
                  <span>IF HELD FOR REVIEW</span>
                  <span className="text-[10px] text-emerald-600 uppercase font-mono">Protected Cash Flow</span>
                </div>
                <p className="text-slate-700 dark:text-slate-300 leading-relaxed">{exception.whatIfHeld}</p>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* ─────────────────────────────────────────────────────────────
          SECTION 13 — HUMAN-IN-THE-LOOP DECISION CENTER
         ───────────────────────────────────────────────────────────── */}
      <div className="bg-white dark:bg-slate-900 p-6 md:p-8 rounded-2xl border-2 border-slate-900 dark:border-slate-100 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-widest text-slate-500 font-mono">
              SECTION 13 • HUMAN DECISION CENTER
            </span>
            <h3 className="text-xl font-black text-slate-900 dark:text-slate-100 mt-1">
              Final Human Approval Authority
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              AI provides evidence, risk, and recommendations. The human retains legal authority.
            </p>
          </div>

          <div className="text-right text-xs">
            <span className="text-slate-500 block">Logged In Reviewer:</span>
            <span className="font-bold text-slate-900 dark:text-slate-100">
              {currentUser.name} ({currentUser.role})
            </span>
          </div>
        </div>

        <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-slate-600 dark:text-slate-400 max-w-md">
            {isDecisionRecorded ? (
              <div className="p-3 bg-slate-100 dark:bg-slate-800 rounded-lg">
                <span className="font-semibold text-slate-900 dark:text-slate-100">Recorded Decision:</span>{' '}
                <strong className="text-amber-600 uppercase">{exception.decision}</strong> by {exception.decidedByName} at {exception.decidedAt ? new Date(exception.decidedAt).toLocaleTimeString() : ''}.
                <p className="italic text-slate-500 mt-1">“{exception.decisionReason}”</p>
              </div>
            ) : (
              <p>
                Clicking <strong className="text-amber-600">HOLD</strong> follows the AI recommendation and flags the invoice for Procurement review.
              </p>
            )}
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
            <Button
              variant="outline"
              size="lg"
              onClick={() => openDecisionDialog('APPROVED')}
              leftIcon={<CheckCircle2 className="w-4 h-4 text-emerald-600" />}
            >
              APPROVE
            </Button>

            <Button
              variant="warning"
              size="lg"
              onClick={() => openDecisionDialog('HELD')}
              leftIcon={<PauseCircle className="w-4 h-4 text-white" />}
            >
              HOLD INVOICE
            </Button>

            <Button
              variant="danger"
              size="lg"
              onClick={() => openDecisionDialog('REJECTED')}
              leftIcon={<XCircle className="w-4 h-4 text-white" />}
            >
              REJECT
            </Button>
          </div>
        </div>
      </div>

      {/* ─────────────────────────────────────────────────────────────
          SECTION 14 — AUDIT TRAIL
         ───────────────────────────────────────────────────────────── */}
      <Card
        title={
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-slate-700 dark:text-slate-300" />
              <span>Immutable Audit Trail</span>
            </div>
            <span className="text-xs font-mono text-slate-400 font-normal">
              {auditLogs.length} Events Logged
            </span>
          </div>
        }
        subtitle="Complete verifiable log of every AI analysis step and human decision"
      >
        <div className="space-y-3">
          {auditLogs.map((log) => (
            <div
              key={log.id}
              className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-lg border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
            >
              <div className="flex items-start gap-3">
                <span className="font-mono text-[11px] text-slate-400 shrink-0 mt-0.5">
                  {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                </span>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 dark:text-slate-100">{log.action}</span>
                    <span className="text-[11px] text-slate-500 font-mono">by {log.userName} ({log.userRole})</span>
                  </div>
                  {log.reason && <p className="text-slate-600 dark:text-slate-300 mt-0.5">{log.reason}</p>}
                </div>
              </div>
              <span className="text-[10px] text-slate-400 font-mono shrink-0">
                Log ID: {log.id}
              </span>
            </div>
          ))}
        </div>
      </Card>

      {/* Modals */}
      <SourceDocumentModal
        isOpen={Boolean(selectedDocForModal)}
        onClose={() => setSelectedDocForModal(null)}
        document={selectedDocForModal}
      />

      <DecisionModal
        isOpen={decisionModalOpen}
        onClose={() => setDecisionModalOpen(false)}
        exception={exception}
        decisionType={targetDecision}
      />

      <ErpExportModal
        isOpen={erpModalOpen}
        onClose={() => setErpModalOpen(false)}
        transaction={transaction}
      />
    </div>
  );
};
