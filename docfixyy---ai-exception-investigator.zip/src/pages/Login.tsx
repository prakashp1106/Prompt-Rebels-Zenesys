import React, { useState } from 'react';
import { Sparkles, ShieldCheck, ArrowRight, UserCheck, Lock, Mail } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { useStore } from '../hooks/useStore';
import { SEEDED_USERS } from '../services/store';

export const Login: React.FC<{ onLoginSuccess: () => void }> = ({ onLoginSuccess }) => {
  const [state, store] = useStore();
  const [email, setEmail] = useState('sarah.j@abcelectronics.com');
  const [password, setPassword] = useState('••••••••••••');
  const [isLoading, setIsLoading] = useState(false);

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLoginSuccess();
    }, 400);
  };

  const handleSelectPersona = (userId: string) => {
    store.switchUser(userId);
    const user = SEEDED_USERS.find((u) => u.id === userId);
    if (user) setEmail(user.email);
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLoginSuccess();
    }, 300);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-center py-12 sm:px-6 lg:px-8 text-slate-100">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center space-y-3">
        <div className="w-12 h-12 rounded-2xl bg-white text-slate-950 flex items-center justify-center font-black tracking-tight text-xl mx-auto shadow-md">
          DF
        </div>
        <div>
          <h2 className="text-3xl font-black tracking-tight uppercase text-white">DOCFIXYY</h2>
          <p className="text-xs text-amber-400 font-mono tracking-wider uppercase font-semibold mt-1">
            AI Business Exception Investigator
          </p>
        </div>
        <p className="text-xs text-slate-400 max-w-xs mx-auto">
          “From different documents to one business truth — and from business truth to the right action.”
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4">
        <div className="bg-slate-900 py-8 px-6 sm:px-10 rounded-2xl border border-slate-800 shadow-2xl space-y-6">
          <form onSubmit={handleSignIn} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Enterprise Email
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="block w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-700 bg-slate-950 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-400"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="block w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-700 bg-slate-950 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-400"
                />
              </div>
            </div>

            <Button
              type="submit"
              variant="primary"
              size="lg"
              className="w-full bg-white text-slate-950 hover:bg-slate-100 font-bold"
              isLoading={isLoading}
              rightIcon={<ArrowRight className="w-4 h-4" />}
            >
              Sign In to Workspace
            </Button>
          </form>

          {/* Quick Demo Switcher */}
          <div className="pt-4 border-t border-slate-800 space-y-2">
            <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block text-center">
              1-Click Demo Persona Sign In
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleSelectPersona('user-sarah')}
                className="p-2 bg-slate-800/80 hover:bg-slate-800 rounded-lg border border-slate-700 text-left text-xs transition-colors cursor-pointer"
              >
                <div className="font-bold text-white">Sarah Jenkins</div>
                <div className="text-[10px] text-amber-400 font-mono">Finance Lead</div>
              </button>

              <button
                type="button"
                onClick={() => handleSelectPersona('user-david')}
                className="p-2 bg-slate-800/80 hover:bg-slate-800 rounded-lg border border-slate-700 text-left text-xs transition-colors cursor-pointer"
              >
                <div className="font-bold text-white">David Chen</div>
                <div className="text-[10px] text-indigo-400 font-mono">Procurement Lead</div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
