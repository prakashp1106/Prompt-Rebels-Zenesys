import React from 'react';
import {
  TrendingUp,
  AlertTriangle,
  Layers,
  ArrowRight,
  ShieldCheck,
  Building2,
  DollarSign,
  CheckCircle2,
  HelpCircle,
} from 'lucide-react';
import { useStore } from '../hooks/useStore';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';

export const RecurringIssues: React.FC<{ onNavigateToInvestigation: () => void }> = ({
  onNavigateToInvestigation,
}) => {
  const [state] = useStore();
  const { recurringPatterns } = state;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 tracking-tight">
            Recurring Business Problems
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            DocFixyy identifies systemic vendor discrepancies that keep happening across cycles.
          </p>
        </div>

        <Button
          variant="primary"
          size="md"
          onClick={onNavigateToInvestigation}
          rightIcon={<ArrowRight className="w-4 h-4" />}
        >
          Back to Live Investigation
        </Button>
      </div>

      {/* Hero Narrative Banner */}
      <div className="p-6 bg-slate-900 text-white rounded-2xl border border-slate-800 shadow-md">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-[11px] font-bold uppercase tracking-widest text-indigo-400 font-mono">
            HISTORICAL INTELLIGENCE ENGINE
          </span>
        </div>
        <h3 className="text-xl font-bold text-slate-100">
          “Stop fixing the same mistake 12 times a month.”
        </h3>
        <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
          DocFixyy aggregates cross-transaction pattern signals. When an exception occurs, the system immediately connects it to historical precedents, isolates chronic vendor behaviors, and proposes structural policy fixes.
        </p>
      </div>

      {/* ─────────────────────────────────────────────────────────────
          PATTERN CARDS GRID
         ───────────────────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {recurringPatterns.map((pattern) => {
          const isHighest = pattern.type === 'QUANTITY_MISMATCH';

          return (
            <Card
              key={pattern.id}
              variant={isHighest ? 'warning' : 'default'}
              title={
                <div className="flex items-start justify-between gap-2 w-full">
                  <div>
                    <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                      {pattern.title}
                    </h3>
                    <span className="text-xs font-mono text-slate-500 block mt-0.5">
                      Pattern ID: {pattern.id} • Type: {pattern.type}
                    </span>
                  </div>
                  <span
                    className={`px-2.5 py-1 text-xs font-bold rounded-md font-mono shrink-0 ${
                      pattern.trend === 'INCREASING'
                        ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                        : pattern.trend === 'DECREASING'
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                    }`}
                  >
                    Trend: {pattern.trend}
                  </span>
                </div>
              }
            >
              <div className="space-y-4 text-xs">
                {/* Metric stats */}
                <div className="grid grid-cols-3 gap-2.5 text-center">
                  <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-lg border border-slate-200 dark:border-slate-700">
                    <span className="text-2xl font-black text-slate-900 dark:text-slate-100">
                      {pattern.occurrenceCount}
                    </span>
                    <span className="text-[10px] block text-slate-500 font-medium">Cases</span>
                  </div>

                  <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-lg border border-slate-200 dark:border-slate-700">
                    <span className="text-2xl font-black text-slate-900 dark:text-slate-100">
                      {pattern.percentageOfExceptions}%
                    </span>
                    <span className="text-[10px] block text-slate-500 font-medium">Frequency</span>
                  </div>

                  <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-lg border border-slate-200 dark:border-slate-700">
                    <span className="text-sm font-bold text-rose-600 block mt-1 font-mono">
                      ₹{(pattern.totalFinancialImpact / 100000).toFixed(1)}L
                    </span>
                    <span className="text-[10px] block text-slate-500 font-medium">Total Impact</span>
                  </div>
                </div>

                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                  {pattern.description}
                </p>

                {/* Affected vendors */}
                <div>
                  <span className="text-[11px] font-semibold text-slate-500 block mb-1">
                    Affected Vendors:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {pattern.affectedVendors.map((vendor, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium text-[11px] border border-slate-200 dark:border-slate-700"
                      >
                        {vendor}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Recommended action */}
                <div className="p-3 bg-indigo-50/60 dark:bg-indigo-950/30 rounded-lg border border-indigo-200 dark:border-indigo-800 text-indigo-950 dark:text-indigo-200">
                  <strong className="block font-semibold mb-0.5">Systemic Remediation:</strong>
                  {pattern.recommendedAction}
                </div>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
};
