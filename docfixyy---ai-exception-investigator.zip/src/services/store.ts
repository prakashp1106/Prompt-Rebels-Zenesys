import { BusinessDocument, CanonicalDocumentSchema } from '../types/document';
import { Transaction } from '../types/transaction';
import { InvestigationException, RecurringPattern, AuditLogEntry } from '../types/exception';
import { User, Organization } from '../types/user';
import { compareDocuments } from '../utils/comparison';
import { calculateDeterministicRisk } from '../utils/risk';

const STORAGE_KEY = 'docfixyy_state_v1';

export const SEEDED_ORG: Organization = {
  id: 'org-abc-elec',
  name: 'ABC Electronics Pvt. Ltd.',
  industry: 'Consumer Technology & Electronics Retail',
  currency: 'INR',
  createdAt: '2026-01-15T09:00:00.000Z',
  createdBy: 'user-sarah',
  status: 'ACTIVE',
};

export const SEEDED_USERS: User[] = [
  {
    id: 'user-sarah',
    orgId: 'org-abc-elec',
    name: 'Sarah Jenkins',
    email: 'sarah.j@abcelectronics.com',
    role: 'Finance',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'user-david',
    orgId: 'org-abc-elec',
    name: 'David Chen',
    email: 'david.c@abcelectronics.com',
    role: 'Procurement',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'user-priya',
    orgId: 'org-abc-elec',
    name: 'Priya Sharma',
    email: 'priya.s@abcelectronics.com',
    role: 'Admin',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
  },
];

export const SEEDED_RECURRING_PATTERNS: RecurringPattern[] = [
  {
    id: 'pattern-1',
    orgId: 'org-abc-elec',
    type: 'QUANTITY_MISMATCH',
    title: 'Procurement Quantity & Shipment Shortage Variance',
    description:
      'Vendors invoicing for full Purchase Order quantities despite warehouse GRN confirming partial physical delivery shortages.',
    occurrenceCount: 12,
    percentageOfExceptions: 38,
    trend: 'INCREASING',
    affectedVendors: ['ABC Suppliers', 'Apex Hardware Ltd.', 'Global Tech Distributors'],
    totalFinancialImpact: 1485000,
    currency: 'INR',
    recommendedAction:
      'Mandate automated 3-way GRN lock before invoice approval; establish mandatory vendor shortage credit notes.',
    createdAt: '2026-06-01T10:00:00.000Z',
    updatedAt: '2026-08-21T18:30:00.000Z',
  },
  {
    id: 'pattern-2',
    orgId: 'org-abc-elec',
    type: 'PRICE_MISMATCH',
    title: 'Vendor Contract Rate Deviations',
    description:
      'Billed line-item rates higher than contracted rate cards and negotiated purchase order terms.',
    occurrenceCount: 7,
    percentageOfExceptions: 21,
    trend: 'STABLE',
    affectedVendors: ['FastLogistics Corp', 'Metro Components Ltd.'],
    totalFinancialImpact: 620000,
    currency: 'INR',
    recommendedAction: 'Re-audit master service agreements and update automated price book validations in ERP.',
    createdAt: '2026-06-10T11:00:00.000Z',
    updatedAt: '2026-08-18T14:15:00.000Z',
  },
  {
    id: 'pattern-3',
    orgId: 'org-abc-elec',
    type: 'MISSING_EVIDENCE',
    title: 'Unsigned Transporter / Proof of Delivery Slips',
    description:
      'High-value electronics shipments accepted at logistics docks without counter-signed vendor delivery notes.',
    occurrenceCount: 5,
    percentageOfExceptions: 14,
    trend: 'INCREASING',
    affectedVendors: ['ABC Suppliers', 'Express Freight India'],
    totalFinancialImpact: 890000,
    currency: 'INR',
    recommendedAction: 'Enforce warehouse gate security checklist upload before GRN status confirmation.',
    createdAt: '2026-07-01T09:30:00.000Z',
    updatedAt: '2026-08-20T12:00:00.000Z',
  },
  {
    id: 'pattern-4',
    orgId: 'org-abc-elec',
    type: 'DUPLICATE_DOCUMENT',
    title: 'Duplicate Multi-Format Resubmissions',
    description:
      'Vendors submitting both digital PDF invoices and physical scanned tax slips for the same milestone.',
    occurrenceCount: 2,
    percentageOfExceptions: 6,
    trend: 'DECREASING',
    affectedVendors: ['Regional Wholesale Logistics'],
    totalFinancialImpact: 195000,
    currency: 'INR',
    recommendedAction: 'Enable vendor portal deduplication hash checks on upload.',
    createdAt: '2026-07-15T15:00:00.000Z',
    updatedAt: '2026-08-10T16:45:00.000Z',
  },
];

export const INITIAL_DOCUMENTS: BusinessDocument[] = [
  {
    id: 'doc-po-1024',
    orgId: 'org-abc-elec',
    fileName: 'PO-1024_ABC_Electronics_Laptops.pdf',
    fileSize: '248 KB',
    fileType: 'application/pdf',
    type: 'PURCHASE_ORDER',
    vendor: 'ABC Suppliers',
    customer: 'ABC Electronics Pvt. Ltd.',
    documentNumber: 'PO-1024',
    documentDate: '2026-08-15',
    referenceNumbers: ['REQ-2026-0891'],
    extractedFields: {
      documentType: 'PURCHASE_ORDER',
      documentNumber: 'PO-1024',
      documentDate: '2026-08-15',
      vendor: 'ABC Suppliers',
      customer: 'ABC Electronics Pvt. Ltd.',
      currency: 'INR',
      referenceNumbers: ['REQ-2026-0891'],
      lineItems: [
        {
          description: 'Enterprise ThinkPad Laptops (Core i7 / 16GB RAM / 512GB SSD)',
          quantity: 100,
          unitPrice: 50000,
          lineTotal: 5000000,
          partNumber: 'TP-LPT-i7-G3',
        },
      ],
      subtotal: 5000000,
      tax: 900000,
      total: 5900000,
    },
    confidenceScores: {
      documentType: 0.99,
      documentNumber: 0.98,
      documentDate: 0.97,
      vendor: 0.99,
      lineItems: 0.96,
      total: 0.98,
      overall: 0.98,
    },
    patternMatch: {
      recognized: true,
      patternName: 'Standard ERP Purchase Order Form',
      layoutType: 'ERP_STANDARD_PO',
      semanticMappingSummary: 'Mapped "Order Number" -> documentNumber, "Order Total" -> total',
    },
    documentDnaProfile: {
      vendorId: 'vend-abc',
      vendorName: 'ABC Suppliers',
      layoutVariant: 'MODERN_CORPORATE',
      knownFieldAliases: {
        docNumberAlias: 'Order Number',
        totalAlias: 'Total Order Value',
        vendorAlias: 'Vendor Name',
      },
      avgConfidence: 0.97,
      historicalTransactionCount: 42,
    },
    processingStatus: 'PROCESSED',
    relatedTransactionId: 'txn-1001',
    uploadedBy: 'user-david',
    uploadedByName: 'David Chen',
    createdAt: '2026-08-22T08:30:00.000Z',
    updatedAt: '2026-08-22T08:30:10.000Z',
    rawTextSnippet: 'PURCHASE ORDER: PO-1024. Vendor: ABC Suppliers. Deliver to: ABC Electronics Pvt. Ltd. 100 units Laptops @ Rs 50,000.',
    isSample: true,
  },
  {
    id: 'doc-grn-9021',
    orgId: 'org-abc-elec',
    fileName: 'GRN-9021_Warehouse_Receipt_Shortage.pdf',
    fileSize: '192 KB',
    fileType: 'application/pdf',
    type: 'GRN',
    vendor: 'ABC Suppliers',
    customer: 'ABC Electronics Pvt. Ltd. (Dock 4 Warehouse)',
    documentNumber: 'GRN-9021',
    documentDate: '2026-08-20',
    referenceNumbers: ['PO-1024', 'WB-440192'],
    extractedFields: {
      documentType: 'GRN',
      documentNumber: 'GRN-9021',
      documentDate: '2026-08-20',
      vendor: 'ABC Suppliers',
      customer: 'ABC Electronics Pvt. Ltd. (Dock 4 Warehouse)',
      currency: 'INR',
      referenceNumbers: ['PO-1024', 'WB-440192'],
      lineItems: [
        {
          description: 'Enterprise ThinkPad Laptops (Core i7 / 16GB RAM) [PHYSICALLY RECEIVED]',
          quantity: 95,
          unitPrice: 50000,
          lineTotal: 4750000,
          partNumber: 'TP-LPT-i7-G3',
        },
      ],
      subtotal: 4750000,
      tax: 855000,
      total: 5605000,
    },
    confidenceScores: {
      documentType: 0.98,
      documentNumber: 0.97,
      documentDate: 0.96,
      vendor: 0.98,
      lineItems: 0.95,
      total: 0.97,
      overall: 0.97,
    },
    patternMatch: {
      recognized: true,
      patternName: 'Warehouse Dock Inward Goods Receipt',
      layoutType: 'WAREHOUSE_GRN_SCAN',
      semanticMappingSummary: 'Mapped "Inward Doc No" -> documentNumber, "Accepted Qty (95)" -> quantity',
    },
    processingStatus: 'PROCESSED',
    relatedTransactionId: 'txn-1001',
    uploadedBy: 'user-david',
    uploadedByName: 'David Chen',
    createdAt: '2026-08-22T08:35:00.000Z',
    updatedAt: '2026-08-22T08:35:12.000Z',
    rawTextSnippet: 'GOODS RECEIPT NOTE: GRN-9021. Ref PO: PO-1024. Received: 95 units. Note: 5 units short/damaged in transit.',
    isSample: true,
  },
  {
    id: 'doc-inv-5001',
    orgId: 'org-abc-elec',
    fileName: 'INV-5001_ABC_Suppliers_Invoice.pdf',
    fileSize: '312 KB',
    fileType: 'application/pdf',
    type: 'INVOICE',
    vendor: 'ABC Suppliers',
    customer: 'ABC Electronics Pvt. Ltd.',
    documentNumber: 'INV-5001',
    documentDate: '2026-08-22',
    referenceNumbers: ['PO-1024'],
    extractedFields: {
      documentType: 'INVOICE',
      documentNumber: 'INV-5001',
      documentDate: '2026-08-22',
      vendor: 'ABC Suppliers',
      customer: 'ABC Electronics Pvt. Ltd.',
      currency: 'INR',
      referenceNumbers: ['PO-1024'],
      lineItems: [
        {
          description: 'Enterprise ThinkPad Laptops (Core i7 / 16GB RAM / 512GB SSD)',
          quantity: 100,
          unitPrice: 50000,
          lineTotal: 5000000,
          partNumber: 'TP-LPT-i7-G3',
        },
      ],
      subtotal: 5000000,
      tax: 900000,
      total: 5900000,
    },
    confidenceScores: {
      documentType: 0.99,
      documentNumber: 0.96,
      documentDate: 0.95,
      vendor: 0.98,
      lineItems: 0.94,
      total: 0.97,
      overall: 0.96,
    },
    patternMatch: {
      recognized: true,
      patternName: 'Modern Corporate Vendor Invoice Layout',
      layoutType: 'MODERN_CORPORATE',
      semanticMappingSummary: 'Mapped "Document Ref: INV-5001" -> documentNumber, "Net Payable Amount" -> total',
    },
    documentDnaProfile: {
      vendorId: 'vend-abc',
      vendorName: 'ABC Suppliers',
      layoutVariant: 'MODERN_CORPORATE',
      knownFieldAliases: {
        docNumberAlias: 'Document Ref',
        totalAlias: 'Net Payable Amount',
        vendorAlias: 'Billed By',
      },
      avgConfidence: 0.96,
      historicalTransactionCount: 42,
    },
    processingStatus: 'REVIEW_REQUIRED',
    relatedTransactionId: 'txn-1001',
    uploadedBy: 'user-sarah',
    uploadedByName: 'Sarah Jenkins',
    createdAt: '2026-08-22T08:42:00.000Z',
    updatedAt: '2026-08-22T08:43:00.000Z',
    rawTextSnippet: 'TAX INVOICE INV-5001. Vendor: ABC Suppliers. PO Ref: PO-1024. Billed: 100 Laptops @ Rs 50,000 = Rs 50,00,000 + 18% GST = Rs 59,00,000.',
    isSample: true,
  },
];

export const INITIAL_EXCEPTION: InvestigationException = {
  id: 'exp-5001',
  txnId: 'txn-1001',
  type: 'QUANTITY_MISMATCH',
  title: 'Invoice billed quantity exceeds Goods Receipt Note (GRN) physical count',
  description:
    'Vendor Invoice #INV-5001 bills for 100 units (₹59,00,000), while warehouse Goods Receipt Note #GRN-9021 confirms receipt of only 95 units (eligible value ₹56,05,000). A 5-unit overbilling discrepancy of ₹2,95,000 is detected.',
  severity: 'HIGH',
  financialImpact: 295000,
  currency: 'INR',
  rootCause:
    'Invoice appears to have been generated using the original Purchase Order quantity (100 units) instead of the actual physical received quantity (95 units) recorded on GRN-9021.',
  rootCauseConfidence: 0.91,
  rootCauseFacts: [
    'Purchase Order PO-1024 ordered 100 ThinkPad Laptops at ₹50,000/unit.',
    'Dock 4 Warehouse GRN-9021 confirmed receipt and barcoding of 95 units on 2026-08-20.',
    'Vendor Invoice INV-5001 dated 2026-08-22 billed for 100 units at ₹50,000 + 18% GST.',
    'Discrepancy: exactly 5 units billed without warehouse receipt record.',
  ],
  rootCauseInferences: [
    'Vendor automated accounts receivable generated the invoice prematurely off the initial sales order copy rather than receiving electronic dispatch clearance from the delivery truck.',
    'The 5-unit shortage was either transit loss or held back as a backorder by ABC Suppliers.',
  ],
  evidence: [
    {
      documentId: 'doc-po-1024',
      documentType: 'Purchase Order',
      documentNumber: 'PO-1024',
      field: 'Authorized Quantity',
      value: '100 units',
      note: 'Contracted order quota with ABC Suppliers.',
    },
    {
      documentId: 'doc-grn-9021',
      documentType: 'Goods Receipt Note',
      documentNumber: 'GRN-9021',
      field: 'Physical Warehouse Receipt',
      value: '95 units',
      note: 'Verified and barcode scanned at Dock 4. 5 units missing upon container unsealing.',
    },
    {
      documentId: 'doc-inv-5001',
      documentType: 'Vendor Invoice',
      documentNumber: 'INV-5001',
      field: 'Billed Quantity & Total',
      value: '100 units (₹59,00,000)',
      note: 'Demands payment for full 100 units without credit adjustment for 5 missing units.',
    },
  ],
  missingEvidence: [
    {
      id: 'me-1',
      title: 'Transporter Signed Proof of Delivery (POD)',
      expectedDocument: 'Vendor Delivery Confirmation Slip with Dock Inward Stamp',
      impactDescription: 'Without vendor signed POD, impossible to confirm whether 100 units were dispatched or short-shipped.',
      responsibleParty: 'ABC Suppliers / Logistics Driver',
      status: 'MISSING',
    },
  ],
  ownerTeam: 'Procurement',
  ownerReason:
    'Exception originates from purchase-order vs physical vendor fulfillment reconciliation. Procurement owns vendor communications and credit note negotiations.',
  recommendation: 'Hold invoice and verify received quantity with Procurement before releasing payment.',
  whatIfApproved:
    'If approved as-is, ABC Electronics will incur an immediate cash leak of ₹2,95,000 for 5 unreceived laptops, resulting in unrecoverable inventory ledger variances during quarterly statutory audit.',
  whatIfHeld:
    'If held for review, Procurement can issue an automated Discrepancy Notice to ABC Suppliers to provide a ₹2,95,000 credit note or schedule subsequent delivery without penalizing cash flow.',
  status: 'OPEN',
  decision: 'PENDING',
  priority: 'HIGH',
  createdAt: '2026-08-22T08:43:30.000Z',
  updatedAt: '2026-08-22T08:43:30.000Z',
  isAiGenerated: true,
  isFallback: false,
};

export const INITIAL_TRANSACTION: Transaction = {
  id: 'txn-1001',
  orgId: 'org-abc-elec',
  transactionCode: 'TXN-2026-ABC-1001',
  vendor: 'ABC Suppliers',
  customer: 'ABC Electronics Pvt. Ltd.',
  poNumber: 'PO-1024',
  grnNumber: 'GRN-9021',
  invoiceNumber: 'INV-5001',
  documentIds: ['doc-po-1024', 'doc-grn-9021', 'doc-inv-5001'],
  businessStory:
    'ABC Electronics ordered 100 laptops from ABC Suppliers. The GRN confirms receipt of 95 units, while the invoice requests payment for 100 units. DocFixyy detected a 5-unit quantity discrepancy.',
  timeline: [
    {
      id: 'tl-1',
      time: '08:30 AM',
      date: '2026-08-22',
      title: 'Purchase Order PO-1024 Processed',
      description: 'Authorized 100 Enterprise Laptops @ ₹50,000 (Total ₹59,00,000 incl. GST).',
      type: 'UPLOAD',
      actor: 'David Chen (Procurement)',
      status: 'COMPLETED',
    },
    {
      id: 'tl-2',
      time: '08:35 AM',
      date: '2026-08-22',
      title: 'Warehouse GRN-9021 Logged',
      description: 'Dock 4 inspection verified physical receipt of 95 units.',
      type: 'NORMALIZATION',
      actor: 'Warehouse System',
      status: 'COMPLETED',
    },
    {
      id: 'tl-3',
      time: '08:42 AM',
      date: '2026-08-22',
      title: 'Vendor Invoice INV-5001 Uploaded',
      description: 'Multi-format document layout recognized; normalized to canonical business schema.',
      type: 'EXTRACTION',
      actor: 'Sarah Jenkins (Finance)',
      status: 'COMPLETED',
    },
    {
      id: 'tl-4',
      time: '08:43 AM',
      date: '2026-08-22',
      title: 'Deterministic Discrepancy Flagged',
      description: '5-unit mismatch detected between physical GRN (95) and Invoice (100).',
      type: 'EXCEPTION_DETECTED',
      actor: 'DocFixyy Comparison Engine',
      status: 'FLAGGED',
    },
    {
      id: 'tl-5',
      time: '08:43 AM',
      date: '2026-08-22',
      title: 'AI Root Cause & Risk Calculated',
      description: 'Deterministic Risk scored at 82/100 (HIGH). Root cause identified (91% confidence).',
      type: 'RISK_CALCULATED',
      actor: 'DocFixyy AI Engine (Gemini 3.7)',
      status: 'COMPLETED',
    },
  ],
  status: 'PENDING_DECISION',
  riskScore: 82,
  riskLevel: 'HIGH',
  riskAssessment: {
    score: 82,
    level: 'HIGH',
    factors: [
      {
        name: 'Quantity Discrepancy',
        weight: 25,
        scoreContribution: 25,
        description: 'Invoice billed quantity (100) exceeds warehouse GRN physical receipt (95).',
        triggered: true,
      },
      {
        name: 'Missing Supporting Evidence',
        weight: 15,
        scoreContribution: 15,
        description: 'Missing vendor signed delivery acknowledgement slip.',
        triggered: true,
      },
      {
        name: 'Recurring Vendor Pattern',
        weight: 15,
        scoreContribution: 15,
        description: '12 similar quantity shortage exceptions recorded across previous 90 days (38% frequency).',
        triggered: true,
      },
      {
        name: 'Financial Exposure Threshold',
        weight: 20,
        scoreContribution: 20,
        description: 'Unverified financial exposure of ₹2,95,000 exceeds ₹1,00,000 threshold.',
        triggered: true,
      },
      {
        name: 'Price Deviation Check',
        weight: 25,
        scoreContribution: 0,
        description: 'Unit price matches contracted PO price at ₹50,000.',
        triggered: false,
      },
    ],
    summary:
      'Risk is HIGH (Score: 82/100) because the transaction contains a physical quantity discrepancy (+5 units), missing vendor proof-of-delivery, and matches a recurring pattern of 12 historical cases.',
    calculatedAt: '2026-08-22T08:43:30.000Z',
  },
  comparison: {
    fields: [
      {
        field: 'quantity',
        label: 'Total Units (Laptops)',
        poValue: 100,
        grnValue: 95,
        invoiceValue: 100,
        mismatch: true,
        delta: '+5 units',
        unit: 'units',
        severity: 'HIGH',
      },
      {
        field: 'unitPrice',
        label: 'Unit Price',
        poValue: '₹50,000',
        grnValue: 'N/A (Logistics)',
        invoiceValue: '₹50,000',
        mismatch: false,
        delta: null,
        unit: 'INR',
        severity: 'LOW',
      },
      {
        field: 'subtotal',
        label: 'Taxable Subtotal',
        poValue: '₹50,00,000',
        grnValue: '₹47,50,000 (Received)',
        invoiceValue: '₹50,00,000',
        mismatch: true,
        delta: '+₹2,50,000 excess',
        unit: 'INR',
        severity: 'HIGH',
      },
      {
        field: 'tax',
        label: 'GST / Tax (18%)',
        poValue: '₹9,00,000',
        grnValue: '₹8,55,000 (Eligible)',
        invoiceValue: '₹9,00,000',
        mismatch: true,
        delta: '+₹45,000 excess',
        unit: 'INR',
        severity: 'MEDIUM',
      },
      {
        field: 'total',
        label: 'Total Amount Due',
        poValue: '₹59,00,000',
        grnValue: '₹56,05,000 (Eligible)',
        invoiceValue: '₹59,00,000',
        mismatch: true,
        delta: '+₹2,95,000 exposure',
        unit: 'INR',
        severity: 'HIGH',
      },
    ],
    lineItemDiffs: [
      {
        itemDescription: 'Enterprise ThinkPad Laptops (Core i7 / 16GB)',
        poQty: 100,
        grnQty: 95,
        invQty: 100,
        poUnitPrice: 50000,
        invUnitPrice: 50000,
        qtyDelta: 5,
        priceDelta: 0,
        financialExposure: 295000,
        mismatch: true,
      },
    ],
    summary:
      'ABC Electronics ordered 100 units. GRN confirms receipt of 95 units, while Invoice requests payment for 100 units. Detected a 5-unit overbilling discrepancy of ₹2,95,000.',
  },
  exceptions: [INITIAL_EXCEPTION],
  openExceptionCount: 1,
  totalInvoiceAmount: 5900000,
  currency: 'INR',
  createdAt: '2026-08-22T08:30:00.000Z',
  updatedAt: '2026-08-22T08:43:30.000Z',
};

export const INITIAL_AUDIT_LOGS: AuditLogEntry[] = [
  {
    id: 'aud-1',
    orgId: 'org-abc-elec',
    txnId: 'txn-1001',
    userId: 'user-sarah',
    userName: 'Sarah Jenkins',
    userRole: 'Finance',
    action: 'DOCUMENT_UPLOAD',
    timestamp: '2026-08-22T08:42:00.000Z',
    reason: 'Uploaded vendor invoice INV-5001 for 3-way reconciliation.',
    metadata: { fileName: 'INV-5001_ABC_Suppliers_Invoice.pdf', docType: 'INVOICE' },
  },
  {
    id: 'aud-2',
    orgId: 'org-abc-elec',
    txnId: 'txn-1001',
    userId: 'system-ai',
    userName: 'DocFixyy AI Engine',
    userRole: 'System',
    action: 'NORMALIZATION_COMPLETED',
    timestamp: '2026-08-22T08:42:15.000Z',
    reason: 'Document layout pattern matched: Modern Corporate Vendor Invoice.',
  },
  {
    id: 'aud-3',
    orgId: 'org-abc-elec',
    txnId: 'txn-1001',
    userId: 'system-ai',
    userName: 'DocFixyy Comparison Engine',
    userRole: 'System',
    action: 'EXCEPTION_DETECTED',
    timestamp: '2026-08-22T08:43:00.000Z',
    reason: 'Quantity mismatch detected: 100 units invoiced vs 95 units physically received.',
  },
  {
    id: 'aud-4',
    orgId: 'org-abc-elec',
    txnId: 'txn-1001',
    userId: 'system-ai',
    userName: 'DocFixyy AI Engine (Gemini 3.7)',
    userRole: 'System',
    action: 'ROOT_CAUSE_GENERATED',
    timestamp: '2026-08-22T08:43:30.000Z',
    reason: 'Investigated discrepancy cause with 91% confidence score.',
  },
];

export interface AppState {
  currentUser: User;
  organization: Organization;
  documents: BusinessDocument[];
  transactions: Transaction[];
  recurringPatterns: RecurringPattern[];
  auditLogs: AuditLogEntry[];
  demoMode: boolean;
}

class Store {
  private state: AppState;
  private listeners: Set<() => void> = new Set();

  constructor() {
    this.state = this.loadState();
  }

  private loadState(): AppState {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.warn('Failed to load local state, using initial seed:', e);
    }
    return {
      currentUser: SEEDED_USERS[0], // Sarah Jenkins (Finance)
      organization: SEEDED_ORG,
      documents: INITIAL_DOCUMENTS,
      transactions: [INITIAL_TRANSACTION],
      recurringPatterns: SEEDED_RECURRING_PATTERNS,
      auditLogs: INITIAL_AUDIT_LOGS,
      demoMode: true,
    };
  }

  private saveState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
    } catch (e) {
      console.warn('Failed to persist state:', e);
    }
    this.notify();
  }

  public subscribe(listener: () => void) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    for (const listener of this.listeners) {
      listener();
    }
  }

  public getState(): AppState {
    return this.state;
  }

  public switchUser(userId: string) {
    const user = SEEDED_USERS.find((u) => u.id === userId);
    if (user) {
      this.state.currentUser = user;
      this.saveState();
    }
  }

  public resetToSeededDemo() {
    this.state = {
      currentUser: SEEDED_USERS[0],
      organization: SEEDED_ORG,
      documents: INITIAL_DOCUMENTS,
      transactions: [INITIAL_TRANSACTION],
      recurringPatterns: SEEDED_RECURRING_PATTERNS,
      auditLogs: INITIAL_AUDIT_LOGS,
      demoMode: true,
    };
    this.saveState();
  }

  public addDocument(doc: BusinessDocument) {
    this.state.documents = [doc, ...this.state.documents];
    this.saveState();
  }

  public updateDocument(id: string, updates: Partial<BusinessDocument>) {
    this.state.documents = this.state.documents.map((d) => (d.id === id ? { ...d, ...updates, updatedAt: new Date().toISOString() } : d));
    this.saveState();
  }

  public recordHumanDecision(
    txnId: string,
    exceptionId: string,
    decision: 'APPROVED' | 'HELD' | 'REJECTED',
    reason: string
  ) {
    const user = this.state.currentUser;
    const now = new Date().toISOString();

    this.state.transactions = this.state.transactions.map((txn) => {
      if (txn.id !== txnId) return txn;

      const updatedExceptions: InvestigationException[] = txn.exceptions.map((ex) => {
        if (ex.id !== exceptionId) return ex;
        const exceptionStatus: 'OPEN' | 'IN_REVIEW' | 'RESOLVED' =
          decision === 'APPROVED' ? 'RESOLVED' : decision === 'HELD' ? 'IN_REVIEW' : 'RESOLVED';
        return {
          ...ex,
          decision,
          decidedBy: user.id,
          decidedByName: `${user.name} (${user.role})`,
          decidedAt: now,
          decisionReason: reason,
          status: exceptionStatus,
        };
      });

      const newStatus = decision === 'HELD' ? 'RESOLVED_HOLD' : decision === 'APPROVED' ? 'RESOLVED_APPROVED' : 'RESOLVED_REJECTED';

      const decisionTimelineEvent = {
        id: `tl-dec-${Date.now()}`,
        time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        date: new Date().toISOString().split('T')[0],
        title: `Human Review: Invoice Placed on ${decision}`,
        description: `Decision recorded by ${user.name} (${user.role}). Reason: "${reason}".`,
        type: 'DECISION' as const,
        actor: `${user.name} (${user.role})`,
        status: 'COMPLETED' as const,
      };

      return {
        ...txn,
        exceptions: updatedExceptions,
        status: newStatus,
        timeline: [...txn.timeline, decisionTimelineEvent],
        updatedAt: now,
      };
    });

    // Add immutable audit log entry
    const auditEntry: AuditLogEntry = {
      id: `aud-${Date.now()}`,
      orgId: this.state.organization.id,
      txnId,
      exceptionId,
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: `DECISION_${decision}`,
      timestamp: now,
      reason,
      metadata: {
        decision,
        targetExceptionId: exceptionId,
        userEmail: user.email,
      },
    };

    this.state.auditLogs = [auditEntry, ...this.state.auditLogs];
    this.saveState();
  }
}

export const store = new Store();
