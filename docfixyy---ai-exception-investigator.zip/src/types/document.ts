export type DocumentType = 'PURCHASE_ORDER' | 'GRN' | 'INVOICE' | 'RECEIPT' | 'UNKNOWN';

export type ProcessingStatus =
  | 'UPLOADED'
  | 'VALIDATING'
  | 'PROCESSING'
  | 'NORMALIZING'
  | 'MATCHING'
  | 'PROCESSED'
  | 'REVIEW_REQUIRED'
  | 'FAILED';

export interface LineItem {
  description: string;
  quantity: number;
  unitPrice: number;
  lineTotal: number;
  partNumber?: string;
}

export interface CanonicalDocumentSchema {
  documentType: DocumentType;
  documentNumber: string;
  documentDate: string;
  vendor: string;
  customer: string;
  currency: string;
  referenceNumbers: string[];
  lineItems: LineItem[];
  subtotal: number;
  tax: number;
  total: number;
}

export interface ExtractionConfidence {
  documentType: number;
  documentNumber: number;
  documentDate: number;
  vendor: number;
  lineItems: number;
  total: number;
  overall: number;
}

export interface DocumentDnaProfile {
  vendorId: string;
  vendorName: string;
  layoutVariant: 'MODERN_CORPORATE' | 'TRADITIONAL_GST' | 'SCANNED_COMPACT' | 'CUSTOM';
  knownFieldAliases: {
    docNumberAlias: string;
    totalAlias: string;
    vendorAlias: string;
  };
  sampleFileUrl?: string;
  avgConfidence: number;
  historicalTransactionCount: number;
}

export interface BusinessDocument {
  id: string;
  orgId: string;
  fileName: string;
  fileUrl?: string;
  fileSize?: string;
  fileType?: string;
  storagePath?: string;
  type: DocumentType;
  vendor: string;
  customer: string;
  documentNumber: string;
  documentDate: string;
  referenceNumbers: string[];
  extractedFields: CanonicalDocumentSchema;
  confidenceScores: ExtractionConfidence;
  patternMatch: {
    recognized: boolean;
    patternName: string;
    layoutType: string;
    semanticMappingSummary: string;
  };
  documentDnaProfile?: DocumentDnaProfile;
  processingStatus: ProcessingStatus;
  relatedTransactionId?: string;
  uploadedBy: string;
  uploadedByName: string;
  createdAt: string;
  updatedAt: string;
  rawTextSnippet?: string;
  isSample?: boolean;
}
