export type ExceptionType =
  | 'PRICE_MISMATCH'
  | 'QUANTITY_MISMATCH'
  | 'DATE_MISMATCH'
  | 'TAX_MISMATCH'
  | 'VENDOR_MISMATCH'
  | 'DUPLICATE_DOCUMENT'
  | 'MISSING_EVIDENCE'
  | 'PAYMENT_MISMATCH'
  | 'TIMELINE_CONTRADICTION'
  | 'HISTORICAL_DEVIATION';

export type ExceptionSeverity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
export type OwnerTeam = 'Procurement' | 'Finance' | 'Operations' | 'Legal' | 'Audit';
export type DecisionType = 'PENDING' | 'APPROVED' | 'HELD' | 'REJECTED';

export interface EvidenceItem {
  documentId: string;
  documentType: string;
  documentNumber: string;
  field: string;
  value: string | number;
  highlightCoordinates?: { x: number; y: number; width: number; height: number };
  note?: string;
}

export interface MissingEvidenceItem {
  id: string;
  title: string;
  expectedDocument: string;
  impactDescription: string;
  responsibleParty: string;
  status: 'MISSING' | 'REQUESTED' | 'WAIVED' | 'RESOLVED';
}

export interface WhatIfScenario {
  ifApproved: string;
  ifHeld: string;
  aiGenerated: boolean;
  generatedAt: string;
}

export interface InvestigationException {
  id: string;
  txnId: string;
  type: ExceptionType;
  title: string;
  description: string;
  severity: ExceptionSeverity;
  financialImpact: number;
  currency: string;
  rootCause: string;
  rootCauseConfidence: number;
  rootCauseFacts: string[];
  rootCauseInferences: string[];
  evidence: EvidenceItem[];
  missingEvidence: MissingEvidenceItem[];
  ownerTeam: OwnerTeam;
  ownerReason: string;
  recommendation: string;
  whatIfApproved: string;
  whatIfHeld: string;
  status: 'OPEN' | 'IN_REVIEW' | 'RESOLVED';
  decision: DecisionType;
  decidedBy?: string;
  decidedByName?: string;
  decidedAt?: string;
  decisionReason?: string;
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  createdAt: string;
  updatedAt: string;
  isAiGenerated?: boolean;
  isFallback?: boolean;
}

export interface RecurringPattern {
  id: string;
  orgId: string;
  type: ExceptionType;
  title: string;
  description: string;
  occurrenceCount: number;
  percentageOfExceptions: number;
  trend: 'INCREASING' | 'STABLE' | 'DECREASING';
  affectedVendors: string[];
  totalFinancialImpact: number;
  currency: string;
  recommendedAction: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuditLogEntry {
  id: string;
  orgId: string;
  txnId: string;
  exceptionId?: string;
  userId: string;
  userName: string;
  userRole: string;
  action: string;
  timestamp: string;
  reason?: string;
  metadata?: Record<string, any>;
}
