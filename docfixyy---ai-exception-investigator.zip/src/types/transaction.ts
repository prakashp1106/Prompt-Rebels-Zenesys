import { InvestigationException } from './exception';
import { CanonicalDocumentSchema } from './document';

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface RiskFactor {
  name: string;
  weight: number;
  scoreContribution: number;
  description: string;
  triggered: boolean;
}

export interface RiskAssessment {
  score: number; // 0 - 100
  level: RiskLevel;
  factors: RiskFactor[];
  summary: string;
  calculatedAt: string;
}

export interface TimelineEvent {
  id: string;
  time: string;
  date: string;
  title: string;
  description: string;
  type: 'UPLOAD' | 'EXTRACTION' | 'NORMALIZATION' | 'LINKING' | 'EXCEPTION_DETECTED' | 'RISK_CALCULATED' | 'HUMAN_REVIEW' | 'DECISION';
  actor: string;
  status: 'COMPLETED' | 'PENDING' | 'FLAGGED';
}

export interface ComparisonFieldDiff {
  field: string;
  label: string;
  poValue: string | number | null;
  grnValue: string | number | null;
  invoiceValue: string | number | null;
  mismatch: boolean;
  delta: string | number | null;
  unit?: string;
  severity?: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
}

export interface TransactionComparison {
  fields: ComparisonFieldDiff[];
  lineItemDiffs: Array<{
    itemDescription: string;
    poQty: number;
    grnQty: number;
    invQty: number;
    poUnitPrice: number;
    invUnitPrice: number;
    qtyDelta: number;
    priceDelta: number;
    financialExposure: number;
    mismatch: boolean;
  }>;
  summary: string;
}

export interface Transaction {
  id: string;
  orgId: string;
  transactionCode: string;
  vendor: string;
  customer: string;
  poNumber: string;
  grnNumber: string;
  invoiceNumber: string;
  documentIds: string[];
  businessStory: string;
  timeline: TimelineEvent[];
  status: 'IN_INVESTIGATION' | 'PENDING_DECISION' | 'RESOLVED_HOLD' | 'RESOLVED_APPROVED' | 'RESOLVED_REJECTED';
  riskScore: number;
  riskLevel: RiskLevel;
  riskAssessment: RiskAssessment;
  comparison: TransactionComparison;
  exceptions: InvestigationException[];
  openExceptionCount: number;
  totalInvoiceAmount: number;
  currency: string;
  createdAt: string;
  updatedAt: string;
}
