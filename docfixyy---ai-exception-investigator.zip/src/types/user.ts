export type UserRole = 'Admin' | 'Finance' | 'Procurement';

export interface User {
  id: string;
  orgId: string;
  name: string;
  email: string;
  role: UserRole;
  avatarUrl?: string;
}

export interface Organization {
  id: string;
  name: string;
  industry: string;
  logoUrl?: string;
  currency: string;
  createdAt: string;
  createdBy: string;
  status: 'ACTIVE' | 'SUSPENDED';
}
