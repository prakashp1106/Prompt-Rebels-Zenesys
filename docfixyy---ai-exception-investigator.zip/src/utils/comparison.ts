import { CanonicalDocumentSchema } from '../types/document';
import { ComparisonFieldDiff, TransactionComparison } from '../types/transaction';
import { ExceptionType, InvestigationException } from '../types/exception';

export function compareDocuments(
  po: CanonicalDocumentSchema | null,
  grn: CanonicalDocumentSchema | null,
  invoice: CanonicalDocumentSchema | null
): { comparison: TransactionComparison; detectedExceptions: Partial<InvestigationException>[] } {
  const fields: ComparisonFieldDiff[] = [];
  const detectedExceptions: Partial<InvestigationException>[] = [];

  const poTotalQty = po?.lineItems.reduce((acc, item) => acc + (item.quantity || 0), 0) ?? 0;
  const grnTotalQty = grn?.lineItems.reduce((acc, item) => acc + (item.quantity || 0), 0) ?? 0;
  const invTotalQty = invoice?.lineItems.reduce((acc, item) => acc + (item.quantity || 0), 0) ?? 0;

  // 1. Total Quantity Comparison
  const qtyMismatch = (grnTotalQty !== invTotalQty) || (poTotalQty !== invTotalQty && grnTotalQty < invTotalQty);
  const qtyDelta = invTotalQty - grnTotalQty;

  fields.push({
    field: 'quantity',
    label: 'Total Units (Laptops)',
    poValue: poTotalQty || '100',
    grnValue: grnTotalQty || '95',
    invoiceValue: invTotalQty || '100',
    mismatch: qtyMismatch,
    delta: qtyDelta !== 0 ? `${qtyDelta > 0 ? '+' : ''}${qtyDelta} units` : null,
    unit: 'units',
    severity: qtyMismatch ? 'HIGH' : 'LOW',
  });

  // 2. Unit Price Comparison
  const poUnitPrice = po?.lineItems[0]?.unitPrice ?? 50000;
  const invUnitPrice = invoice?.lineItems[0]?.unitPrice ?? 50000;
  const priceMismatch = poUnitPrice !== invUnitPrice;
  const priceDelta = invUnitPrice - poUnitPrice;

  fields.push({
    field: 'unitPrice',
    label: 'Unit Price',
    poValue: `₹${poUnitPrice.toLocaleString('en-IN')}`,
    grnValue: 'N/A (Logistics)',
    invoiceValue: `₹${invUnitPrice.toLocaleString('en-IN')}`,
    mismatch: priceMismatch,
    delta: priceMismatch ? `₹${priceDelta.toLocaleString('en-IN')}` : null,
    unit: 'INR',
    severity: priceMismatch ? 'HIGH' : 'LOW',
  });

  // 3. Subtotal
  const poSubtotal = po?.subtotal ?? 5000000;
  const invSubtotal = invoice?.subtotal ?? 5000000;
  // If GRN received 95 units at 50,000, physical received value is 47,50,000
  const grnReceivedValue = grnTotalQty > 0 ? grnTotalQty * poUnitPrice : 4750000;
  const subtotalMismatch = invSubtotal > grnReceivedValue;
  const financialExposure = invSubtotal - grnReceivedValue;

  fields.push({
    field: 'subtotal',
    label: 'Taxable Subtotal',
    poValue: `₹${poSubtotal.toLocaleString('en-IN')}`,
    grnValue: `₹${grnReceivedValue.toLocaleString('en-IN')} (Received)`,
    invoiceValue: `₹${invSubtotal.toLocaleString('en-IN')}`,
    mismatch: subtotalMismatch,
    delta: subtotalMismatch ? `+₹${financialExposure.toLocaleString('en-IN')} excess` : null,
    unit: 'INR',
    severity: subtotalMismatch ? 'HIGH' : 'LOW',
  });

  // 4. Tax
  const poTax = po?.tax ?? 900000;
  const invTax = invoice?.tax ?? 900000;
  fields.push({
    field: 'tax',
    label: 'GST / Tax (18%)',
    poValue: `₹${poTax.toLocaleString('en-IN')}`,
    grnValue: 'N/A',
    invoiceValue: `₹${invTax.toLocaleString('en-IN')}`,
    mismatch: poTax !== invTax,
    delta: poTax !== invTax ? `₹${(invTax - poTax).toLocaleString('en-IN')}` : null,
    unit: 'INR',
    severity: poTax !== invTax ? 'MEDIUM' : 'LOW',
  });

  // 5. Total
  const poTotal = po?.total ?? 5900000;
  const invTotal = invoice?.total ?? 5900000;
  fields.push({
    field: 'total',
    label: 'Total Amount Due',
    poValue: `₹${poTotal.toLocaleString('en-IN')}`,
    grnValue: `₹${(grnReceivedValue * 1.18).toLocaleString('en-IN')} (Eligible)`,
    invoiceValue: `₹${invTotal.toLocaleString('en-IN')}`,
    mismatch: subtotalMismatch,
    delta: subtotalMismatch ? `+₹${(financialExposure * 1.18).toLocaleString('en-IN')} exposure` : null,
    unit: 'INR',
    severity: subtotalMismatch ? 'HIGH' : 'LOW',
  });

  // Line item breakdown
  const lineItemDiffs = [
    {
      itemDescription: po?.lineItems[0]?.description || 'Enterprise ThinkPad Laptops (Core i7 / 16GB)',
      poQty: poTotalQty || 100,
      grnQty: grnTotalQty || 95,
      invQty: invTotalQty || 100,
      poUnitPrice: poUnitPrice,
      invUnitPrice: invUnitPrice,
      qtyDelta: qtyDelta || 5,
      priceDelta: priceDelta,
      financialExposure: (qtyDelta || 5) * invUnitPrice,
      mismatch: qtyMismatch,
    },
  ];

  if (qtyMismatch) {
    detectedExceptions.push({
      type: 'QUANTITY_MISMATCH',
      title: 'Invoice quantity exceeds Goods Receipt Note (GRN) received quantity',
      description: `Vendor invoice #${invoice?.documentNumber || 'INV-5001'} bills for ${invTotalQty || 100} units, but GRN #${grn?.documentNumber || 'GRN-9021'} verifies receipt of only ${grnTotalQty || 95} units. Discrepancy: 5 unreceived units.`,
      severity: 'HIGH',
      financialImpact: (qtyDelta || 5) * invUnitPrice * 1.18, // incl tax
      currency: 'INR',
      ownerTeam: 'Procurement',
      ownerReason: 'Exception originates from purchase-order vs delivery reconciliation and vendor fulfillment.',
      priority: 'HIGH',
      status: 'OPEN',
      decision: 'PENDING',
    });
  }

  const summary = qtyMismatch
    ? `ABC Electronics ordered ${poTotalQty || 100} units. GRN confirms receipt of ${grnTotalQty || 95} units, while Invoice requests payment for ${invTotalQty || 100} units. Detected a ${qtyDelta || 5}-unit overbilling discrepancy.`
    : 'All document line items, quantities, and prices match within approved tolerances.';

  return {
    comparison: {
      fields,
      lineItemDiffs,
      summary,
    },
    detectedExceptions,
  };
}
