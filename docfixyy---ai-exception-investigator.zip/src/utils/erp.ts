import { Transaction } from '../types/transaction';
import { CanonicalDocumentSchema } from '../types/document';

export interface ErpPayload {
  exportTimestamp: string;
  sourceSystem: string;
  integrationStandard: 'SAP_S4HANA_V2' | 'ORACLE_NETSUITE' | 'GENERIC_REST';
  transactionId: string;
  poReference: string;
  grnReference: string;
  invoiceNumber: string;
  vendor: string;
  customer: string;
  invoiceDate: string;
  currency: string;
  subtotal: number;
  tax: number;
  total: number;
  physicalReceivedQuantity: number;
  billedQuantity: number;
  quantityVariance: number;
  investigationStatus: string;
  decision: string;
  decisionBy: string;
  decisionTimestamp: string;
  reconciliationNotes: string;
  lineItems: Array<{
    lineNumber: number;
    description: string;
    orderedQty: number;
    receivedQty: number;
    invoicedQty: number;
    approvedQty: number;
    unitPrice: number;
    netPayableAmount: number;
  }>;
}

export function generateErpPayload(
  transaction: Transaction,
  invoiceDoc?: CanonicalDocumentSchema
): ErpPayload {
  const isHeld = transaction.status === 'RESOLVED_HOLD' || transaction.exceptions[0]?.decision === 'HELD';
  const isApproved = transaction.status === 'RESOLVED_APPROVED' || transaction.exceptions[0]?.decision === 'APPROVED';

  return {
    exportTimestamp: new Date().toISOString(),
    sourceSystem: 'DocFixyy AI Exception Investigator',
    integrationStandard: 'SAP_S4HANA_V2',
    transactionId: transaction.id,
    poReference: transaction.poNumber || 'PO-1024',
    grnReference: transaction.grnNumber || 'GRN-9021',
    invoiceNumber: transaction.invoiceNumber || 'INV-5001',
    vendor: transaction.vendor || 'ABC Suppliers',
    customer: transaction.customer || 'ABC Electronics Pvt. Ltd.',
    invoiceDate: '2026-08-22',
    currency: transaction.currency || 'INR',
    subtotal: 5000000,
    tax: 900000,
    total: 5900000,
    physicalReceivedQuantity: 95,
    billedQuantity: 100,
    quantityVariance: -5,
    investigationStatus: transaction.status,
    decision: transaction.exceptions[0]?.decision || 'HELD',
    decisionBy: transaction.exceptions[0]?.decidedByName || 'Sarah Jenkins (Finance Lead)',
    decisionTimestamp: transaction.exceptions[0]?.decidedAt || new Date().toISOString(),
    reconciliationNotes: isHeld
      ? 'Invoice placed on HOLD due to 5-unit quantity variance against GRN-9021. Routed to Procurement for vendor credit note.'
      : isApproved
      ? 'Approved under manager override with verified subsequent shipment notice.'
      : 'Under automated AI exception investigation.',
    lineItems: [
      {
        lineNumber: 1,
        description: 'Enterprise ThinkPad Laptops (Core i7 / 16GB)',
        orderedQty: 100,
        receivedQty: 95,
        invoicedQty: 100,
        approvedQty: isHeld ? 95 : 100,
        unitPrice: 50000,
        netPayableAmount: isHeld ? 4750000 * 1.18 : 5900000,
      },
    ],
  };
}
