export function formatCurrency(amount: number, currency: string = 'INR'): string {
  if (isNaN(amount)) return '₹0';
  if (currency === 'INR') {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  }
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatPercentage(value: number): string {
  return `${Math.round(value * 100)}%`;
}

export function formatConfidenceBadge(score: number): { label: string; color: string; bg: string } {
  const pct = Math.round(score * 100);
  if (pct >= 90) {
    return { label: `${pct}% High`, color: 'text-emerald-700 dark:text-emerald-300', bg: 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-800' };
  } else if (pct >= 70) {
    return { label: `${pct}% Moderate`, color: 'text-amber-700 dark:text-amber-300', bg: 'bg-amber-50 dark:bg-amber-950/60 border-amber-200 dark:border-amber-800' };
  }
  return { label: `${pct}% Review Required`, color: 'text-rose-700 dark:text-rose-300', bg: 'bg-rose-50 dark:bg-rose-950/60 border-rose-200 dark:border-rose-800' };
}

export function getRiskLevelBadge(level: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL') {
  switch (level) {
    case 'CRITICAL':
      return { label: 'CRITICAL RISK', bg: 'bg-rose-500 text-white', border: 'border-rose-600', text: 'text-rose-600 dark:text-rose-400' };
    case 'HIGH':
      return { label: 'HIGH RISK', bg: 'bg-amber-500 text-slate-950 font-bold', border: 'border-amber-500', text: 'text-amber-600 dark:text-amber-400' };
    case 'MEDIUM':
      return { label: 'MEDIUM RISK', bg: 'bg-yellow-100 text-yellow-800 border-yellow-300 dark:bg-yellow-950/50 dark:text-yellow-300', border: 'border-yellow-400', text: 'text-yellow-600' };
    default:
      return { label: 'LOW RISK', bg: 'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-950/50 dark:text-emerald-300', border: 'border-emerald-400', text: 'text-emerald-600' };
  }
}
