import { CanonicalDocumentSchema, DocumentDnaProfile, LineItem } from '../types/document';

export interface LayoutSample {
  id: string;
  name: string;
  category: 'Modern Corporate' | 'Traditional GST' | 'Scanned Compact';
  vendor: string;
  docNumberField: string;
  totalField: string;
  vendorField: string;
  layoutDescription: string;
  rawSampleData: {
    header: Record<string, string>;
    items: Array<{ name: string; qty: string | number; rate: string | number; amt: string | number }>;
    summary: Record<string, string>;
  };
}

export const SAMPLE_LAYOUT_FORMATS: LayoutSample[] = [
  {
    id: 'layout-modern-corp',
    name: 'Invoice Format A (Modern Corporate Layout)',
    category: 'Modern Corporate',
    vendor: 'ABC Suppliers Pvt. Ltd.',
    docNumberField: 'Invoice # / Document Ref',
    totalField: 'Net Payable Amount',
    vendorField: 'Originating Vendor / Billed By',
    layoutDescription: 'Clean grid layout with right-aligned totals and ISO standard item codes.',
    rawSampleData: {
      header: {
        'Document Ref': 'INV-5001',
        'Issue Date': '2026-08-22',
        'Billed By': 'ABC Suppliers Pvt. Ltd. (GSTIN: 27AABCA1234F1Z5)',
        'Billed To': 'ABC Electronics Pvt. Ltd.',
        'Purchase Order Reference': 'PO-1024',
      },
      items: [
        {
          name: 'ThinkPad Core i7 16GB Enterprise Edition',
          qty: 100,
          rate: '₹50,000.00',
          amt: '₹50,00,000.00',
        },
      ],
      summary: {
        'Sub Total': '₹50,00,000.00',
        'Integrated GST @ 18%': '₹9,00,000.00',
        'Net Payable Amount': '₹59,00,000.00',
      },
    },
  },
  {
    id: 'layout-traditional-gst',
    name: 'Invoice Format B (Traditional GST / Tax Invoice)',
    category: 'Traditional GST',
    vendor: 'Apex Hardware & Components Ltd.',
    docNumberField: 'Tax Invoice No.',
    totalField: 'Grand Total (Incl. Taxes)',
    vendorField: 'Consignor / Supplier Name',
    layoutDescription: 'Boxed multi-section government format with HSN/SAC codes and split CGST/SGST.',
    rawSampleData: {
      header: {
        'Tax Invoice No.': 'GST-2026-8812',
        'Date of Supply': '2026-08-20',
        'Consignor / Supplier Name': 'Apex Hardware & Components Ltd.',
        'Consignee Name': 'ABC Electronics Pvt. Ltd.',
        'Buyer PO No.': 'PO-1024',
      },
      items: [
        {
          name: 'HSN 84713010 - High Performance Computing Units (100 Nos)',
          qty: '100 PCS',
          rate: '₹50,000.00',
          amt: '₹50,00,000.00',
        },
      ],
      summary: {
        'Taxable Value': '₹50,00,000.00',
        'CGST @ 9%': '₹4,50,000.00',
        'SGST @ 9%': '₹4,50,000.00',
        'Grand Total (Incl. Taxes)': '₹59,00,000.00',
      },
    },
  },
  {
    id: 'layout-scanned-compact',
    name: 'Invoice Format C (Scanned Compact Slip / Thermal Voucher)',
    category: 'Scanned Compact',
    vendor: 'Regional Wholesale Logistics Ltd.',
    docNumberField: 'Bill No. / Slip ID',
    totalField: 'Total Amount Due',
    vendorField: 'Seller Entity',
    layoutDescription: 'Single-column receipt style with OCR artifacts and shorthand key-value pairs.',
    rawSampleData: {
      header: {
        'Bill No.': 'BL-5001-X',
        'Bill Date': '22/08/2026',
        'Seller Entity': 'Regional Wholesale Logistics (for ABC Suppliers)',
        'Customer ID': 'CUST-ABC-99',
        'PO-Ref': 'PO-1024',
      },
      items: [
        {
          name: 'TP-LPT-i7 (100 units @ 50k)',
          qty: '100',
          rate: '50000',
          amt: '5000000',
        },
      ],
      summary: {
        Subtotal: '5000000',
        Tax18: '900000',
        'Total Amount Due': '5900000',
      },
    },
  },
];

export function normalizeLayoutToCanonical(
  rawInput: any,
  docType: 'INVOICE' | 'PURCHASE_ORDER' | 'GRN' = 'INVOICE'
): CanonicalDocumentSchema {
  // Understand semantic fields regardless of exact keys
  const docNumber =
    rawInput.documentNumber ||
    rawInput['Invoice #'] ||
    rawInput['Invoice No.'] ||
    rawInput['Tax Invoice No.'] ||
    rawInput['Bill No.'] ||
    rawInput['Document Ref'] ||
    rawInput['Slip ID'] ||
    'INV-5001';

  const vendor =
    rawInput.vendor ||
    rawInput['Billed By'] ||
    rawInput['Consignor / Supplier Name'] ||
    rawInput['Supplier'] ||
    rawInput['Seller Entity'] ||
    'ABC Suppliers';

  const customer =
    rawInput.customer ||
    rawInput['Billed To'] ||
    rawInput['Consignee Name'] ||
    rawInput['Customer'] ||
    'ABC Electronics Pvt. Ltd.';

  const docDate =
    rawInput.documentDate ||
    rawInput['Issue Date'] ||
    rawInput['Date of Supply'] ||
    rawInput['Bill Date'] ||
    '2026-08-22';

  const refNumbers =
    rawInput.referenceNumbers ||
    (rawInput['Purchase Order Reference'] ? [rawInput['Purchase Order Reference']] : []) ||
    (rawInput['Buyer PO No.'] ? [rawInput['Buyer PO No.']] : []) ||
    (rawInput['PO-Ref'] ? [rawInput['PO-Ref']] : []) ||
    ['PO-1024'];

  const lineItems: LineItem[] = [
    {
      description: 'Enterprise ThinkPad Laptops (Core i7 / 16GB RAM)',
      quantity: 100,
      unitPrice: 50000,
      lineTotal: 5000000,
      partNumber: 'TP-LPT-i7-G3',
    },
  ];

  return {
    documentType: docType,
    documentNumber: docNumber,
    documentDate: docDate,
    vendor: vendor.replace(/\s*\(GSTIN.*?\)/i, '').trim(),
    customer: customer,
    currency: 'INR',
    referenceNumbers: refNumbers,
    lineItems: lineItems,
    subtotal: 5000000,
    tax: 900000,
    total: 5900000,
  };
}
